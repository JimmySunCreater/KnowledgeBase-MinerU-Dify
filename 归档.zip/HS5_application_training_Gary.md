# HS5 Application Training ---SIH 12 Service  

Presented by Gary  

## HS5 Application Training 目录  

电液泵控形式回顾-  
PQ控制结构介绍-  
HS5 软件介绍-- --10调试步骤- 11  

### HS5 Application Training电液泵控形式回顾  

EP：电比例控制排量，无摆角反馈，开环。排量与比例阀电磁铁电流成正比。  

EO1/EO2：电比例控制排量，带摆角反馈。闭环流量控制，内部基于实际摆角的PI控制器  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/cae0743b2b4c02e58327a3c820c30cc8cb5829dbb0613db3592cfc44ce7b2644.jpg  

#### EO2回路图-规格40至355  

油口P上由外部提供的控制液压油通过泵的排油口R（L）从内部排出。  
带有EO2的A4CSG不需要控制压力溢流阀，只需更换一个螺纹塞即可。  
为了使控制油油耗降至最低，对于规格125...355的行程腔必须加以密封，并可通过油口 $\mathtt{R}_{2}$ 至R实现排气  

#### 规格40和71  

示例：开式回路A4VSO  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/b06dffa7d7306533f76cd29e26b60b5cf284bcc96403cab25bb3e15156ba6a23.jpg  

### HS5 Application Training电液泵控形式回顾  

HS：电伺服控制排量，带摆角反馈，闭环流量控制。  

HS3&4 系列：带摆角反馈和压力反馈的闭环PQ控制泵。软件调整，流量为P比例控制器，压力为PI控制器  

#### HS回路图  

规格40和71 示例：开式回路A4VSO  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/7256a8a9c8babd4683cbded9726d2340551f72f3bc2f69e7a0ad9529548758eb.jpg  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/a2aade27a8e0bdf42c7a0e38436371d197ab156dcae141769c88f17c2735fd9a.jpg  

### HS5 Application Training电液泵控形式回顾  

DFEn：带摆角反馈、压力反馈和电机转速控制的闭环PQ控制泵，节能型。软件调整  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/ddc04cab216fc319ebdbaf325cf72bcbfbf84493d1196b85c9b3d18d87c4d15e.jpg  

HS5 系列：带摆角反馈和压力反馈的闭环PQ控制泵，可选带电机转速控制功能。软件调整，针对不同应用，可选串联结构和级联结构。  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/c5d385534fa10ea2c2753e6e21973429d8225431b48373a6a40471328c3e9bcd.jpg  

#### 可选系列:  

伺服阀 (HS);比例阀 (HS5);短路阀(HSK, HS5K, HS5KP);▶ 油浸式 (HS5M);内控油 (HS5V);集成式放大器阀 (HS5E).集成转速控制 (HS5n?)—未上市  

## HS5 Application Training  

### 电液泵控形式回顾  

<html><body><table><tr><td>控制形式</td><td>控制阀</td><td>摆角反馈</td><td>压力反馈</td><td>控制器</td><td>板卡</td><td>软件</td><td>响应速度 0-100%</td><td>滞环</td><td>重复精度</td></tr><tr><td>EP系列</td><td>比例无阀芯反馈</td><td>无</td><td>无</td><td>Q</td><td>VT3000 模拟板</td><td>无</td><td>200 ms</td><td>5...7 %</td><td>< 2 %</td></tr><tr><td>EO系列</td><td>比例无阀芯反馈</td><td>LVDT</td><td>无</td><td>Q</td><td>VT5035 模拟板</td><td>无</td><td>200 ms</td><td>2%</td><td><1.5 %</td></tr><tr><td>HS</td><td>伺服无阀芯反馈</td><td>LVDT</td><td>无</td><td>Q</td><td>VT-SR7 模拟板</td><td>无</td><td>100 ms</td><td>≤ 0.2%</td><td>≤ 0.2%</td></tr><tr><td>HS3&HS4</td><td>比例带阀芯反馈</td><td>LVDT</td><td>HM20</td><td>PQ</td><td>VT12350 VT-VPCD 数字板</td><td>BODIV BODAC</td><td>100 ms</td><td>≤ 0.2%</td><td>≤ 0.2%</td></tr><tr><td>DFEn</td><td>比例带阀芯反馈</td><td>2-10V模拟量</td><td>HM20</td><td>PQ+N</td><td>集成 数字板</td><td>WinPED 5.10</td><td>100 ms</td><td>≤ 0.2%</td><td>≤ 0.2%</td></tr><tr><td>HS5系列</td><td>HS5(V,P)：比例无阀芯反馈 HS5E：比例带阀芯反馈，OBE</td><td>2-10V/4-20mA 模拟量</td><td>HM20</td><td>PQ+N(可选)</td><td>VT-HPC 集成 数字板</td><td>Indraworks(DS)</td><td>100 ms</td><td>≤ 0.2%</td><td>≤ 0.2%</td></tr></table></body></html>  

NOTE: $\rightarrow$ 只有EP才能在开环情况下根据阀电流调节排量。  

$\rightarrow$ EO及以上的闭环控制泵，均无法在开环情况下根据阀电流调节排量（阀电流的大小只影响摆角打开或关闭的快慢程度）。  

## HS5 Application TrainingPQ控制结构介绍  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/8d68ff0e610bf6e0147da369ca060f8f451c79b8be477964d148edcab1901f7d.jpg  

Simultanious setting of max pressure and   
Flow   
同时设置最大压力和流量   
Keeping traverse speed profile at low   
pressure   
在低压时保持速度曲线跟随   
Autonomous change over to pressure   
control at set point pressure level   
在到达设定压力点时，自动切换到压力   
控制   
Keeping pressure command at small swivel   
angle   
在小摆角的情况下，保持压力控制恒定  

### HS5 Application TrainingPQ控制结构介绍---Parallel Structure  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/9faf436258c6fa2d27b07568e4373539aea87f3b7a979278f1f46547c6155688.jpg  

Pressure controller and flow controller working in parallel压力和流量并行控制  

Advantage: pressure control is fast   
优势：压力控制较快   
Disadvantage: The wrong valve zero position can have bigger effect on pressure controller compared to Cascade structure.   
劣势：相比Cascade结构,非核定零点位置对精确的压力控制有较大负面影响 NOTE:   
阀补偿矫正会对压力控制 产生较好效果。  

### HS5 Application TrainingPQ控制结构介绍---Cascade Structure  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/b00a4705d627d1b95cc226b5c8374c182db3d2185ff8327d7e841e584bd5a9b6.jpg  

在将摆角指令值输入到实际的摆角控制器之前，可通过摆角指令值处理中的各种变量来调整摆角指令值。摆角指令值处理和压力控制器的输出将传递到转换逻辑。 在转换逻辑中生成对控制有效的摆角指令值。 在实际压力值采集功能中，将比较各种实际压力值，并为转换逻辑生成结果符号。摆角控制器的输出被传递到输出调整。  

优点：积分器功能可保证压力控制稳定及精度，无须进行阀校正；缺点：相对于Parallel来说，响应不够快，意味着负载变化太快时会出现过冲情况。  

系列:▶ HS4▶ HS5  

只有HS5才能在两种结构之间切换！  

NOTE:  
油管内油液容积dead volume须被纳入计算，用于PQ的计算。  

## HS5 Application Training HS5软件介绍  

HS5系列泵的控制器，均使用Indraworks平台进行参数设置或编程；  

 Indraworks DS：用于参数设置，状态监控，曲线采集；--免费  

$\rightarrow$ Indraworks Engineering：除DS功能外，增加工程开发，编程等功能；--付费  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/2ed39121deda4f00dd40622ba7959c3d3669b1b17a00baae82f6f125dc2d6737.jpg  

详细设置步骤请查看调试步骤章节  

## HS5 Application Training 调试步骤  

1. 接线检查  
2. 管路配置  
3. 软件配置  
4. Easy Start 模式调试  
5. Operating mode下的闭环控制  
6. 系统运行  
7. 闭环PID参数调节  
8. 曲线采集  

### HS5 Application Training 调试步骤—接线检查  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/7e739df9e9054f1acb9c737bcc29a5e90652c5dc5ad2bd7845be62a6a165310e.jpg  

### HS5 Application Training 调试步骤—接线检查  

#### 摆角传感器：  

Voltage input  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/8637cd11c88b2108a2d89cc572a7cc8033997083707471224082b3a4661053e9.jpg  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/3f99a34fdd37439e50dce637d967bbafe54941cf47af2a0faea614831928674c.jpg  

传感器有电流、电压两种接法：  

1. 电流接法：1,3,4   a6,b6,b5  
2. 电压接法：1,2,3   a6,a5,b6  
2\~10V对应摆角范围-100%\~100%，中位为6V。  
4-20mA对应摆角范围-100%\~100%，中位为12mA  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/2c6c38e8efc6b168044204b8c04572bdca4472514b9090b2a4d8d5eaf93fda7f.jpg  

## HS5 Applicatio n Training  

### 调试步骤—接线检查  

压力传感器及比例阀：  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/3c2278a4085f94397095d581ded396040be80053e46d15223fb0d03939b629fe.jpg  

压力传感器可按照信号类型接线：  

1.电源：电源可使用外部电源（如上图），可以利用HPC上的DO点作为传感器的供电电源；  
2.电流信号：b1公共端，b2\~b5可选；  
3.电压信号：a2,b2为正负端，类比至a5,b5；  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/229b0f3e375b47402b6f531340aa8272e7553fcbd40ae159bc81374671ad70bb.jpg  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/d75ff5d34c19bba4f50230c2505f5e4802655f8aecca1baa95642eb58282a30d.jpg  

### HS5 Application Training 调试步骤—管路配置  

1. 压力传感器安装位置必须在单向阀前；  

以海瑞克盾构机上的应用为例  

#### 注意事项：  

2. 压力传感器和单向阀之间的油液容积，不能低于6L。经验认为，之间的管路长度须 $\ge1.5\mathrm{m}$ ；  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/0ad6006adcf379c842a9273c3aeb0e7b9843f987cb0a85e53ab75a823cbfc652.jpg  

### HS5 Application Training 调试步骤—软件配置  

#### 软件连接： IndraWorks DS V14V14及以上版本  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/c46475ccaf0792f162462a9440c42e62624c0735dd8fd0a16219171fcdde3791.jpg  

#### Note:  

1. 电脑IP地址须与HPC同一个网段；  
2. Setting可用于自动修改电脑IP为同一网段；  

## HS5 Application Training  

调试步骤—软件配置  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/d9c354e9e29b7693e7f244a09b0ac4c273c057d7b02b83defbf383c65e3f6cbf.jpg  

本地连接的IP地址设置完成后，回到Indraworks DS软件正常连接即可。  

### HS5 Application Training 调试步骤—软件配置  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/ca550e18ab7ca48cded3d2cce08168a3dec59231821a3e673d943d7775c9c0a1.jpg  

### HS5 Application Training 调试步骤—软件配置  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/764ac93123da3e7d0f0e9d2fece7885d23852416679337292f892f9f17235b67.jpg  

### HS5 Application Training 调试步骤—软件配置  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/5160fa67dfe8be5abf12abd5984a0425972d3c7d2ee6a8054374ebb10b34f73e.jpg  

## HS5 Applicatio n Training  

### 调试步骤—软件配置  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/a835e7b604ad6a7f16cb5edbfe94f0e774e5da0bf776a4bc76d7f716ab30de6f.jpg  

### HS5 Application Training 调试步骤—软件配置  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/f333dd652bc56deb5b2d6403e462f649753a31314dd864bbc6c3a93bbc9b635c.jpg  

## HS5 Application Training  

### 调试步骤—Easy Start 模式  

软件提供调试模式，用于开环及闭环调试，以判断接线和控制功能是否正常。  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/aac066055bca24fa51560c6f91b7138de5a6bd36f53402611a274d3e2a805a96.jpg  

### HS5 Application Training调试步骤—Opearting mode下的闭环控制  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/8fc09275bd9bdd2525dcb6079094011e48286584ff745d777d0d8441229c2427.jpg  

### HS5 Application Training 调试步骤—软件配置  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/3bfa5dce20d0514cd07b8dffa09a412346c621ad6c7a6589e6086c64e975a8da.jpg  

### HS5 Application Training 调试步骤—软件配置  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/215456393c2f35283c1616c47180a4b7307b90bd9ed393c305e8f0fbb10ccd7a.jpg  

### HS5 Application Training调试步骤—系统运行  

（1）确保系统无报警，接线正常的情况下，给HPC通电；  
（2）通电后，延迟几秒，上使能Enable；  
（3）设定待机压力和流量，启动电机；  
（4）改变指令设定值，检查动作是否正常；  
（5）PID调节；  
（6）曲线采集；  

### HS5 Application Training 调试步骤—PID调节  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/96971c3e6f085b564f44595fb07d6f99859e84e86404b2a2cb3af11d0346eeb6.jpg  

Parallel结构压力控制器调节：  

### HS5 Application Training 调试步骤—PID调节  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/d9e4c4f74dbdc883c7fe732208cda7c3e6982734228a60821acd3c4223705c6b.jpg  

Cascade结构压力控制器调节：  

1. P-gain：提高压力响应；  
2. I：稳定压力及消除跟随误差；  
3. D：稳态微分；  

### HS5 Application Training调试步骤—Parallel结构下的阀校正  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/cb6ce50296090704079a21b22b9fbb6a01e53d2fc7bf382bc66baca45de00fbb.jpg  
NOTE: Cascade结构下压力控制精度靠积分器补偿  

从最低压力至最高额定压力，设定8个压力点，作为压力控制的阀补偿值。  
校正成功后将更新补偿值；  

### HS5 Application Training调试步骤—曲线采集  

S-0-0800： 压力指令值 S-0-0809： 实际压力值 S-0-0880： 摆角指令值 S-0-0882：实际摆角值  

P-0-2951：控制器状态字P-0-2950：控制字（压力控制器激活/摆角控制器激活）  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HS5_application_training_Gary/images/841bc24672d82276d3bd100efb140c6dc8893a2b5d7389cfc20913bde179c84f.jpg  