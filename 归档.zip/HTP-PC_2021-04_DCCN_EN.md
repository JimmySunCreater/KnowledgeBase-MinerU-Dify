# Control electronics for pump A4V..HS5(E) and SYDFED  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/38e3f393be20edae68911d1f1822f0df01e4e0790eff9725fb190920470250c2.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED  

# Agenda  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/0e75e32a03a85b804d95cc5e4e27c956d27237e90665dc70a3f7d6f8da00df2a.jpg  

## Control electronics for pump A4V..HS5(E) and SYDFED Learning targets  

 Getting to know the design and use of VT-HPC and SYDFED   
Understanding practical steps for VT-HPC and SYDFED diagnosis Being able to parametrize VT-HPC and SYDFED   
 Understanding the Multi-Ethernet interface  Communication to a superior control   
 Being able to carry out data backup and data restoration  

# Control electronics for pump A4V..HS5(E) and SYDFED Agenda  

 Description of the A4.V..HS5E system using VT-HPC and SYDFED   
 VT-HPC and SYDFED hardware   
 IndraWorks DS operating software Diagnosis options Device replacement   
 Calibration function   
 Practical training on the system  

## Control electronics for pump A4V..HS5(E) and SYDFED Round of introductions  

Name Company / Division   
Activity Experience with Bosch Rexroth products  IndraWorks / IndraDrive Experience with control systems  Manufacturer   
Goals for the training  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/bb54fce6b5d25110c2ec743b5c43551c9b032f03db994ce2b141eb13c969abaa.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED Contents  

Hardware properties   
IndraWorks   
First steps in IndraWorks   
Parameter system   
Firmware / function packages   
Easy startup mode   
Integrated oscilloscope   
Scaling / Units   
Swivel angle acquisition   
Force acquisition   
I/O configuration   
Introduction in control circuit, standard behavior   
Best-in-class controller   
DCM-IA/oSPHv12 e| 201m8-11ent limit values and status messages   
Operating modes osch Rexroth AG 2018. All rights reserved, also regarding any disposal, exploitation, reproduction, editing, distribution, as well as in the even  

# Control electronics for pump A4V..HS5(E) and SYDFED  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/7bf900c4be1d46bb8a27b722a483cb5349ec55c96611745197297211d0cdf6bb.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED Documentation  

Technical data sheet RE30237 Operating instructions RE30237-B Information for Pump control RE30237-z Parameter description RE30330-PA Functional description RE30338-FK Description of diagnosis RE30330-WA Online help in IndraWorks  

# Internet  

DFE HS5 (VT-HPC)  

www.boschrexroth.com/SYDFE www.boschrexroth.com/HPC  

## Control electronics for pump A4V..HS5(E) and SYDFED System overview A4.VS..HS5E  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/632cb8b9a94ab8f2ffaf8072badecc236f36b71fd4ce3c2ad1b8c0cb0a020e82.jpg  

## Control electronics for pump A4V..HS5(E) and SYDFED Electrical properties  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/7beb2ccf76dae3122359f7437e942ba8e7bd92fdc9a6470d8468142c8e6bddc4.jpg  

## Control electronics for pump A4V..HS5(E) and SYDFED Type code – SY(H)DFED  

<html><body><table><tr><td></td><td colspan="6"></td><td>05 06</td><td>07</td><td>08</td><td></td><td>60</td><td></td><td></td><td>1011</td><td></td><td>12</td><td>13</td><td>14</td><td></td><td>15</td></tr><tr><td>SYHDFED-1X</td><td></td><td>125</td><td>R</td><td></td><td>V</td><td>Z</td><td>B</td><td>25</td><td>U99</td><td></td><td></td><td>0000</td><td>A</td><td></td><td></td><td>A</td><td>S</td><td>F</td><td></td><td></td></tr></table></body></html>  

<html><body><table><tr><td>13</td><td>Sercos Il</td></tr><tr><td>EtherCAT (CANopen profile)</td><td></td></tr><tr><td>VARAN (servo drive profile) Ethernet/IP</td><td>T</td></tr><tr><td></td><td>V</td></tr><tr><td></td><td>E</td></tr><tr><td>PROFINETRT Powerlink</td><td>N</td></tr></table></body></html>  

<html><body><table><tr><td>Actual pressure value input (freely configurable) Parame ter settingexfactory</td><td>Connector</td><td>V 0...10V</td><td>0.5...5V</td><td></td></tr><tr><td>(description of the connectors onpage 20etsq.) 14 Voltage input0..10V</td><td>XH4</td><td></td><td></td><td>V</td></tr><tr><td>Voltage input0.5..5V</td><td>X2M1</td><td></td><td></td><td>F</td></tr></table></body></html>  

### Control electronics for pump A4V..HS5(E) and SYDFED Device connector XH2 – Supply  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/c3d503d2afe7f983b53afb4c5ac0deee8e8aa308eedb2437fef6ec59ab85407e.jpg  

<html><body><table><tr><td>Pin</td><td>Signal</td><td>Description</td></tr><tr><td>1</td><td>+U</td><td>Voltage supply</td></tr><tr><td>2</td><td>OV=LO</td><td>Reference potential for the voltage supply</td></tr><tr><td>PE</td><td>Ground</td><td>Grounding connection for electronics</td></tr><tr><td>3</td><td>Fault</td><td>Signals faults,e.g.cable break command/actual values,controller monitoring （logic O=error)</td></tr><tr><td></td><td>MO</td><td>Reference potential for analog signals</td></tr><tr><td>5</td><td></td><td>Swivel angle command value</td></tr><tr><td>6</td><td>Actual</td><td>Actual swivel angle value,normalized</td></tr><tr><td>7</td><td>PCommand</td><td>Pressure command value</td></tr><tr><td>8</td><td>PA.ctual</td><td>Actual pressure value,normalized</td></tr><tr><td>9</td><td></td><td>Function depends on electronictype and additional function, see below</td></tr><tr><td>10</td><td>Actual pressure valueH</td><td rowspan="2">Actual pressure value input:Signal level depends on feature 14 of the orderingcode With type“F"(0.5...5V)reserved</td></tr><tr><td>11</td><td>Actual pressure value L</td></tr></table></body></html>  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/e03c9ded7866714ce8fd5bb37f61ed1e322e657028abf3eca8f3c7bda6028ced.jpg  

Connector, 11-pole $^+$ PE according to EN 175201-804  

Supply voltage: 24 V DC Power consumption 4WRPDH $\rightarrow$ NG 6: 40 W NG 10: 60 W  

Fuse protection: 4 A, time-lag  

### Control electronics for pump A4V..HS5(E) and SYDFED Ethernet interface X7E1, X7E2  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/f6b3ca83ddf8fbf8eb2238ba378c322c767623f8cb25bd2b5d06eabe936cab3b.jpg  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/641814fc54495d37c3144014869fc3a2036f2c9d14538b8d65418bda66766bab.jpg  

Socket, 4-pole, M12, coding D  The Ethernet interface is an integral part of the ordering key The control communication can be changed via the parameter or via IndraWorks  

<html><body><table><tr><td>Pin</td><td>Assignment</td></tr><tr><td>1</td><td>TxD+</td></tr><tr><td></td><td></td></tr><tr><td>m</td><td>TXD-</td></tr><tr><td>4</td><td>RxD-</td></tr><tr><td></td><td>not assigned</td></tr></table></body></html>  

<html><body><table><tr><td>Type code:</td><td>S</td><td>E</td><td>N</td><td>T</td><td>V</td><td>W</td></tr></table></body></html>

© Bosch Rexroth AG 2018. All rights reserved, also regarding any disposal, exploitation, reproduction, editing, distribution, as well as in the event of applications for industrial property rights.  

### Control electronics for pump A4V..HS5(E) and SYDFED Analog sensor interfaces X2M1, X2M2  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/9e3c53c9c4a3e67de33d1c1feba93d3c1f6cac7d92df799ac5f936f9a7ab973b.jpg  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/7c41008457c0d41697476e98f05d535e8f8874b00ba1a05e1e5dd63be9cca9a8.jpg  

X2M1 and X2M2:Analog configurable sensor interface (coding A)  

<html><body><table><tr><td>Pin</td><td>Assignment</td></tr><tr><td></td><td>+24Vvoltageoutput t(sensor supply)</td></tr><tr><td></td><td>Sensor signal input current(4.20 mA） 2)</td></tr><tr><td>3</td><td>GND</td></tr><tr><td>4</td><td>Sensor signal input voltage(0...10V)2)</td></tr><tr><td>5</td><td>Negative differentialamplifierinput to pin 4（optional)</td></tr></table></body></html>  

Bushing, 5-pole, M12, coding A   
Analog sensor input for pressure or force acquisition   
Assignment freely configurable   
Selection irrespective of the channel:  (0) $4..20~\mathsf{m A}$ or 0.. 10 V or user-defined   
Resolution 12 bit  

## Control electronics for pump A4V..HS5(E) and SYDFED Optical diagnosis  

# Topics:  

Ethernet bus system  

Network status  

Hardware VT-HPC  

### Control electronics for pump A4V..HS5(E) and SYDFED LED displays  

<html><body><table><tr><td>LED</td><td>Interface</td><td>Sercos</td><td>EtherNET/IP</td><td>EtherCAT</td><td>PROFINET</td></tr><tr><td>1</td><td rowspan="2">X7E1</td><td>Activity</td><td>Activity</td><td>Not used</td><td>Activity</td></tr><tr><td>2</td><td>Link</td><td>Link</td><td>Link/activity</td><td>Link</td></tr><tr><td></td><td rowspan="2">Electronics module</td><td></td><td>Networkstatus</td><td>Network status</td><td>Network status</td></tr><tr><td>4</td><td>Modulestatus</td><td>Module status</td><td>Module status</td><td>Module status</td></tr><tr><td>5</td><td rowspan="2">X7E2</td><td>Activity</td><td>Activity</td><td>Not used</td><td>Activity</td></tr><tr><td>6</td><td>Link</td><td>Link</td><td>Link/activity</td><td>Link</td></tr></table></body></html>  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/21b9a114bf18a110bc6b038df50e58200eeae717860279995c25133f753d7534.jpg  

LED 1 and 2 refer to the Ethernet interface X7E1, LED 5 and 6 refer to the Ethernet interface X7E2   
Link – green: Cable plugged in, connection established $\rightarrow$ permanently lit   
Activity – yellow: Data sent/received  flashing  

### Control electronics for pump A4V..HS5(E) and SYDFED LED displays  

Displays of the status LEDs   


<html><body><table><tr><td>Module status LED (LED4)</td><td>Display status</td></tr><tr><td>Off</td><td>No voltage supply</td></tr><tr><td>Green-red,flashing</td><td>Self-test</td></tr><tr><td>Green,flashing</td><td>Drive ready for operation</td></tr><tr><td>Green</td><td>in control</td></tr><tr><td>Red,flashing</td><td>Warning</td></tr><tr><td>Red</td><td>Error</td></tr></table></body></html>  

<html><body><table><tr><td>Network status LED (LED3]</td><td>Display status</td></tr><tr><td>Off</td><td>No voltage supply</td></tr><tr><td>Green</td><td>Operation</td></tr></table></body></html>  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/7449088b8ab85885f40cf62cf1969bc5e0531ba016067183a24db4bb08bb0762.jpg  

 LEDs 3 and 4 relate to the electronics module   
 LED 4 describes the module status   
 LED 3 describes the network status and depends on the selected control communication  

Detailed information in the functional description chapter 9.2.5 Diagnosis LED  

## Control electronics for pump A4V..HS5(E) and SYDFED Accessories  

# SYDFED / HS5E  

<html><body><table><tr><td>AccessoriesforHs5E</td><td>Materialnumber</td><td>Data shee</td></tr><tr><td>Plug-ln connector.i2-plnforcentral.connectionXH4 withoutcable(assemblykit)</td><td>R900884671</td><td>90080</td></tr><tr><td>Plug-inconnector.12-plnforcentralconnectlonXH4 with cableset2x5m</td><td>R900032356</td><td></td></tr><tr><td>Plug-inconnector.12-plnforcentralconnectlonxH4 withcableset2x20m</td><td>R000860399</td><td></td></tr><tr><td>PressuretransducerHm2o-2x. Measuringrange63obar(4..2omA)</td><td>R901342035</td><td></td></tr><tr><td>TestdevlceVT-PDFE-1-1XV0/0</td><td>R900757051</td><td>8-68962</td></tr><tr><td>Compactpowersupply unitVT-NE32-1x</td><td>8900080049</td><td>62662</td></tr><tr><td>AnEthernetMi2toRJ45connectlngcable(portsX7Ei& X7E2j.additlonalinfon matlonIntypedeslgnatloniRkBooddy xxx.x(oot.x:lengthInmeters)</td><td>R911172135</td><td></td></tr></table></body></html>  

# VT-HPC  

<html><body><table><tr><td></td><td></td></tr><tr><td>COHNECTOP PLUG6E57972-0BA42-0XA0f0FD0rtXF30 IPROFBUS</td><td>8901312863</td></tr><tr><td>Connectlon cable PCVT-HPC（RJ45.XF20orXF21） RKB0011/005.0.length:5m</td><td>R911321548</td></tr><tr><td>re IndraWorksDsof verslon14V14or higher (without PLC functlonallty)</td><td></td></tr><tr><td>softwareIndraWorksMLDofverslon14v14orhlgher</td><td></td></tr><tr><td>comml softwareInoraWorksSulteasverslon 14vi4orhicher</td><td></td></tr></table></body></html>  

## Control electronics for pump A4V..HS5(E) and SYDFED HM20-2x for hydraulic applications  

 Measuring pressures in hydraulic systems   
 8 measurement ranges up to 630 bar   
 Sensor with thin film measuring cell   
 Components that are in contact with the media are made of stainless steel   
 Operational safety due to high bursting pressure, reversed polarity, overvoltage and short-circuit protection   
 Accuracy class 0.5   
 Excellent non-repeatability $<0.05\%$   
 Wide operating temperature range –40 ... $+85$ °C  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/f4c98f43834d819b9f6b11ce903bb679055b1f39f4af83762b3a81b130c33d4c.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Basic function  

# Topics:  

Swivel angle controller  

Pressure controller  

Master/slave  

Torque limitation  

# A@fNDAlectronics for pump A4V..HS5(E) and SYDFED  

### Controller functionality  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/b9f0432aef33c109c5eee42a7db2a6a00e9658494605a1e79929bff76eb5375b.jpg  

# Pre-defined hydraulic-specific axis controller functions  

 Swivel angle controller  Pressure controller  Torque limitation  Master/slave  

# @fMDAlectronics for pump A4V..HS5(E) and SYDFED Overview of closed-loop control circuit  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/3e7062bdd3033432cca29f19ab75533116305b62578713a40090484b45f9f6d8.jpg  
Overviewof thecontrollerfunctions（in thecondition assupplied)  

# A@fNDAlectronics for pump A4V..HS5(E) and SYDFED Overview of closed-loop control circuit  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/ecb20872d9b12c866bd87e58048e45723d240a7ec8523335d1ee704eca4df933.jpg  

## Control electronics for pump A4V..HS5(E) and SYDFED Best-in-class controller  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/b4f0f9606ee58f147873568f0fca1c743d04188e8ab4341647619fc60afa366a.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Principles of pressure, swivel angle control  

In the “pressure/swivel angle control” operating mode, a swivel angle command value and a pressure command value is preset for the control pump. If required, these command values can be guided via a ramp generator. There are two different structures (parallel and cascade structure) for the design of the pressure/swivel angle controller. In both cases, swivel angle and pressure controller are simultaneously enabled. A switching logics is used to dynamically switch between both control types. In this connection, the switching logics ensures that only one of the two units of pressure or swivel angle is controlled.  

### Control electronics for pump A4V..HS5(E) and SYDFED Swivel angle controller  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/3e2534193806c799c4d11e3d8a22442384f1c8af642ef3555ba4dcfd7eb1d259.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Parallel structure pressure controller  

P share and D share suitable for small dead volume (pumps with small size)  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/89b96105e517c374ce0034f560e0b8fe468e9ea2b41e5a1086e2a59fd11c44cb.jpg  

Selection switching mode: Switching logics enabled Only pressure control enabled Only swivel angle control enabled  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/dfa6e135687a9a7051b4fd74790ed0af069275b2cf7d5b44dbc3aeeb5a97cdeb.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Cascade structure pressure controller  

# PID controller for large dead volume (pumps with large size)  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/e45df65c9bcbafbcf1b62df9ae333a7bf4181afcd1cd27bbe31ca068c27b89e7.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Master - slave function  

 The master-slave function can be used for multi-pump systems  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/902e7e2eabe82327ccdc2ece2ef0fdb8892f9fa40e2c11ae80f3e659518ed5aa.jpg  

PLC: Must define the master (P-0-2950 Bit 5) Direct copying of the values from master to slave Details: RD30338-FK page 417  

Master: Works like single pump in alternating pressure / swivel angle control The control word for pump control P-0-2950 must contain Bit 5 = 0.  

Slave: Works in swivel angle control only   
The control word for pump control P-0-2950 must contain Bit 5 = 1.   
Swivel angle command value master/slave P0-2935  

# A@MDAlectronics for pump A4V..HS5(E) and SYDFED Pump control  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/ec8e00713323959b3d19c69f4be93f0b37304ef0e030e6690ba9328de5e46f18.jpg  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/32de100c363eacfe387e7c42705eea0021c8dd17d676bf631569274d5e24f5ec.jpg  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/727b968cb50aa9df31a85ec9dd90b54bedc73e8b8f7e3a3fc3fc2f07d5bd1359.jpg  

## Control electronics for pump A4V..HS5(E) and SYDFED What is IndraWorks?  

 IndraWorks DS is the parameterizing software for VT-HPC (HS5), SYDFED and HS5E  

 Depending on the application, different IndraWorks variants are available  

 It is also possible to install different variants or versions in parallel.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/2f912870903bea55bd2883f2e6a8ea1507b2407f994ea0912dc34ca93a0d10d3.jpg  

 Recommendation: Separate folders  

### Control electronics for pump A4V..HS5(E) and SYDFED IndraWorks – Available online  

IndraWorks DS is available for free on the product site online: www.boschrexroth.com/HPC  

# Downloads  

部  

# 1.4GB I Sofhware  

Service tool for drive commissioning; Type code: SWA-IWORKS-DS\*-14VRS-D0-DVD\*-COPY: Self-extracting installtion program,Full installation including online help;No license needed;Installation does not require an activation key; Supported drives $j$ firmware $1$ version:IndraDrive C/MMPB/MPD/MPH/MPCversion 02/03/04/05/06/07/08; IndraDrive Cs/C/M/Mi/ML MPE/MPB/MPC version 16/17/18/19/20: EcoDrive Cs MGP version 01: Hydraulic Drive (HDx) R911347040  

## Control electronics for pump A4V..HS5(E) and SYDFED Installing IndraWorks DS  

Unpacking the downloaded file Starting setup.exe  

 No license is required for the installation of IndraWorks; the license agreement must be accepted  

### Control electronics for pump A4V..HS5(E) and SYDFED Operation of IndraWorks / basic functions  

# Topics:  

Overview   
Connection establishment   
Communication basics   
Navigation   
Axis status   
Digital inputs/outputs  

### Control electronics for pump A4V..HS5(E) and SYDFED IndraWorks DS – Overview  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/eccd0aa07610d1c87de65511d5cd94a555402a19365b332cc235d757d92bdece.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Connection selection – Overview  

# During start, the  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/3878213b8aace6132ea338b7879f20632ebbb729e0497d8bc0d0ef0fd302e6d7.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Connection selection – Search result  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/1baa9483ee3177ddc2aff937ea4465b0f941fd7f2609d41bb51949caada3b140.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Connection selection – IP address settings  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/2517cc9d0eb7d42b27eec2ac1dd3526be0598546819502be38cc574ff32f43a5.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Connection selection – Changing the address in the drive  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/865e006cc77822fd487f2b418640959c202a7e8c76d078b22daaa4502d25fe83.jpg  

## Control electronics for pump A4V..HS5(E) and SYDFED Communication basics  

# IP address  

is assigned to devices which are connected to the network making devices addressable and thus reachable.   
is used for transporting data from their sender to the receiver.   
most popular writing includes four numerical   
values (0 .. 255), separated by a dot.   
Example:  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/699c6244467be34db5016a8d4dbbaf4007c2d6713889318393a771073b5cd839.jpg  

# Network mask (net mask, sub-net mask)  

is a bit mask which defines in the network protocol of how many bits at the beginning of an IP address a network ID is made of.   
in connection with the IP address, the network mask   
defines the IP addresses a device searches in its own network, and which ones can be reached via a router in other networks.   
Thus, it separates the IP address into a network part   
(network ID) and a device part (host ID).  

The network ID must be equal for all devices of the corresponding network, the host ID must be different for each device within the network.  

### Control electronics for pump A4V..HS5(E) and SYDFED IndraWorks DS – Navigation  

 Only one device at a time is active in IndraWorks DS  Only one window at a time is open in the workspace  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/65a5c61b8ba3640f601d7f48761aaaca63b1170b42f7b5321118482bc95dfd7a.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED IndraWorks DS – Device explorer  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/81a76d05e264f78a60411b1afe4b50cd857700c24494b954080c359feeb33e36.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Start screen specification  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/390091bb52726ce53cd4f40250713676ff356ed93f963964a3c5f0c5a51345ef.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED IndraWorks DS / start screen  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/79141b061538b80596674d5846beb1cfcbbf2ebe179d821d9d966f5cc9e5a687.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED IndraWorks DS – Alternative / axis status  

#  This site is automatically opened as start screen for IndraWorks DS  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/83b413d02b71985b6a2c61c32a154ea760a3820f22ffda03cd2bf0af3fc33391.jpg  

## Control electronics for pump A4V..HS5(E) and SYDFED Analog I/O  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/730d6458e96beeaf90829ee522caa23740d8447198b84df5478204209065a28e.jpg  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/f1e57bb347213055a40fe9369242ba737022ba5d6ef34cc16e53cbb11c35c316.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Assignment of analog inputs Notice:  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/4abe22f04b2af5a0fdfbc86fc43862b88dc90c006b8ceb6e187782bcde51ef4a.jpg  

Assignments 1 & 2 are provided for pressure / force acquisition and can only be configured in the Force acquisition dialog  

Parameter assignment  

Signal range depends on the type of signal  

Wire breakage evaluation depends on the type of signal  

Value range of the target parameter (measurement)  

Nominal value & offset depend on the range of values & signals  

# Control electronics for pump A4V..HS5(E) and SYDFED  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/1c4d023203cdd6ef3f4e2d4b34ba73058cca80115079175260fd396f82f0fe16.jpg  

# Evaluation  

# Control electronics for pump A4V..HS5(E) and SYDFED  

# Digital I/O  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/3c1d4f06a6bb3181fc646847e0ecf75eface671ade275b90072974e9392100ef.jpg  

## Control electronics for pump A4V..HS5(E) and SYDFED Parameters of the VT-HPC  

# Topics:  

Definition of parameters  
Parameter information  
Basic parameters  
Operation modes  
Parameter backup  

# G@MDAlectronics for pump A4V..HS5(E) and SYDFED Firmware update  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/9ba21a2eb67d65c2b114f02a3d1d932acb0baa47b2e5a25a8744499cfef49af6.jpg  

# G@MDAlectronics for pump A4V..HS5(E) and SYDFED Firmware update  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/e1f02ceebd7e6fe5615e6c1bd7283ef477b309c811938655084f9711b5e79387.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED  

# What are parameters?  

With a few exceptions, the communication between control system and drive is accomplished by means of parameters.  

Use:  

 Definition of configuration   
 Parameterization of the control loop   
 Triggering and control of drive functions and commands   
 Transmission of target and actual values (on demand, cyclic or acyclic)  

Each parameter has an identification number.  

 They can be read and written. The writing of parameters depends on the properties of the parameter and the communication phase of the drive. Certain parameter values are checked by the drive firmware for validity.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/59a1045c10577ee1878a270bf752e7be1d97b4b8e760e072a1a32684ea54d668.jpg  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/e6caa014e60fac4d7ebfa1f14a0e2a0f92988ba75594a4d6acad1e9874d12887.jpg  

## Control electronics for pump A4V..HS5(E) and SYDFEDS & P parameters  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/4ad95ded84256fa81a11167d33b32bf084085aefa451ef3fa669faec6fd5d975.jpg  

parameters  Standard parameters defined be the sercos standard configuration data (or information) of the drive  

P parameters  Parameters specific for the manufacturer/product according to the sercos standard Configuration data (or information) of the drive  

# Control electronics for pump A4V..HS5(E) and SYDFED  

# Parameter access  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/8544561460b06a9da8e2c9bf58f9366c89c524f283227b66f77c451306d70bf8.jpg  
© Bosch Rexroth AG 2018. All rights reserved, also regarding any disposal, exploitation, reproduction, editing, distribution, as well as in the event of applications for industrial property rights.  

### Control electronics for pump A4V..HS5(E) and SYDFED Parameter editor  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/1d22e38bdb2759ae6bc33de8968ad4b91df0bdea0be530b61be398765ac0a9ef.jpg  

The Help parameter is structured by the firmware version.  

# Control electronics for pump A4V..HS5(E) and SYDFED  

# Searching parameters – Parameter group  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/510058dd8677f4c4519ef26291a2830b62b6fafc64c72e93a2079119dec64458.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Loading basic parameters  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/f39c6e6ebe6ea0861012e1daeffbc925fe6d04c02913b7e140add953019a3c6b.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFEDBasic parameters  

# What are basic parameters?  

The set of basic parameters is a complete parameter set provided at the factory with standard settings for the firmware used.   
The delivery state of the parameter settings can be restored at any time by the ‘Loading the basic parameters’ command.   
Any previously adjusted axis parameters will be overwritten   
The basic parameter set depends on the activated function package  

# The basic parameter set has the following properties:  

Deactivation of optional drive functions Deactivation of position and acceleration limit values Reducing the velocity limit value Setting the torque/force limit values to high values. Activating the main operating mode  

# Control electronics for pump A4V..HS5(E) and SYDFED PM  OM  

 Most of the parameters can only be changed in the parameterization mode (PM Parameter Mode); cyclic command values are then ignored The axis can only be commanded in the operation mode (OM Operation Mode); then only certain parameters can be changed, e.g. Pamplification of the position controller   
 GREEN $=$ mode which can be switched to  

## Control electronics for pump A4V..HS5(E) and SYDFED Saving parameters  

The complete axis configuration can be saved on a file, irrespective of the communication phase of the axis  

Select file name and storage location  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/2cd56ced1876403b562efcfbff473ac1eb89936c4b317e203698d896ce21bfa9.jpg  

#  

### Control electronics for pump A4V..HS5(E) and SYDFEDLoading parameter files  

 Saved axis configuration can be loaded into the axis.   
 To this end, the axis must be in parameterization mode.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/34f88019a8d0ae70059cd6ac91fe0c3532d56ddf62f453181c08315d1d2b5b9b.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED IndraWorks DS – File analysis  

 To view a parameter file in IndraWorks DS, the file must be opened via the Connection selection dialog.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/2a23ff051d6596e918dc98181ba5181ed3bb5ddb76e5506594ca975fd76f4c39.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Step 1: Loading basic parameters  

Load basic parameters of the axis.   
Theparametersarereset tothedefaultsetings.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/7049202a64bb00f58e4e0eea95c2fd01bc30eef82230516bd90ea4868f100a85.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Step 2: Basic configuration  

# Step 2: Basic configuration  

Theinputof thebasicconfigurationisused topre-configurethepump controller system.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/460c3615e12466069c078358fffc21987c251dac5dc0da313633e78369aa050d.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Step 3: Operating mode and function  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/5ac1a46700ba4408ebcb2f0a919ce683ebd7bbc5174b11b31e590b555de72a0b.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Step 4: Scaling and unit of measurement  

# Step 4: Scaling/units  

Detemine scaling and units of the axis.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/5c8095a96a99de91df77a7b5b768592047b716df59560582ee30e1dbbe4c275a.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Step 5: Selection of swivel angle sensor  

Enterthe type and the characteristic data of the connected sensors.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/5915a9ed69e6e0d9c3014009788cc6501b25eeda9d31728aaaca3b85084bee9c.jpg  
Step 5.1: Selection of sensors  

### Control electronics for pump A4V..HS5(E) and SYDFED Step 6: Selection of pressure sensor  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/469f7303b33af3d86913e1fd2c76b065d6e5514cafed0e2fd4ac2404c26f90f7.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Step 7: Selection of command values  

Enterthe nommalization and the signal range of the command values.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/01b3ad27b0fcd2b49d7cf25fbc380a270af1d8f7b85089aacc550930f23ead1c.jpg  
Step 6: Selection of command values  

Source of the pressure command value: Control communication, e.g. Profinet, Sercos, ... Fixed internal command value presetting Analog input  

Source of the swivel angle command   
value: Control communication, e.g. Profinet, Sercos, ... Fixed internal command value presetting Analog input  

### Control electronics for pump A4V..HS5(E) and SYDFED Step 7: Controller configuration  

Select the desired controller structure and parameterize the pressure controller  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/901b4ef10c00e712f2c9db06eedd88faa38e8f6357283e7adc9b7ae85fec4e27.jpg  
Step 7: Controller configuration  

Controller structure selection: Parallel: DFE systems and/or small pumps Cascade: HSx systems and/or large pumps with large dead volume and storage  

Approximate dead volume between pump and actuator  

Controller parameter swivel angle controller The recommended values are accepted by pressing “SET”  

Controller parameter pressure controller The recommended values are accepted by pressing “SET”  

### Control electronics for pump A4V..HS5(E) and SYDFED Last step: Summary  

# Step 8: Summary  

Overviewwindowfor initial parameterization  

# Overview  

# Configuration:  

Hydraulic vanant: "Open circuit (VSO)"   
Selected swivel angle sensor:"AWAX voltage"   
Mode of pressure command value provision:"Analog input 1: 0V-10V"   
Mode of swivel angle provision:"Analog input 2: $\mp,i^{\prime}$ -10V"   
Selected controller structure:"Cascade"  

# Wamings:  

Step 1:Loading of basic parameters has not been executed!  

# Parameterizingiscompleted!  

Please executepump controller calibrationto finalize commissioning.  

## Control electronics for pump A4V..HS5(E) and SYDFED Easy startup mode  

# Short description of the easy startup mode  

The set-up mode as the so-called easy startup mode allows for the movement of a drive without connected and/or active control system (and/or master of the control communication) or external command value box.  

Fields of application: Thus, this mode is especially suited for  

 first commissioning of individual axes without active control communication,  maintenance of a configurable emergency operation (on-site operation) in case of failure of the internal or external control system (and/or control communication).  

# Notice:  

Control communication must not be enabled since the easy startup mode will switch off any active command via the control communication!  

### Control electronics for pump A4V..HS5(E) and SYDFED Prerequisites for easy startup mode  

When does it make sense to enable the easy startup mode?  

Swivel angle control to check the pump  Prerequisites for the pilot oil pressure  System in a safe condition  Controller default setting  

 The easy startup mode must not be enabled during the automatic mode. Otherwise, the command values of the PLC are no longer valid.  

# Control electronics for pump A4V..HS5(E) and SY(H)DFE D Easy startup mode  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/b269e0fb3dd26a3fe25580c2ce858abb6912a3f95e2927f38a4d7bd9a43b7e45.jpg  

 The easy startup mode allows for the movement of a drive without superior control system.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/5ab60c344054bdcc273dacc855837b92286e6cfda26da6f436d1004b8efa9dd6.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED Easy startup mode  

#  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/726ca21a716758820dffb8176343282ea5f5962c2eb184bf664487071709a6ce.jpg  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/24e9bce2f9a413ad57cbd722400b90b8fd20a2f4a540c3d87ac7b730fec2aed8.jpg  

Always in the foreground. By enabling “Drive off”, the release can be reset. Attention! The “Easy startup” mode is still enabled; command values from the superior control system are not accepted.  

# @NDAlectronics for pump A4V..HS5(E) and SY(H)DFED Easy startup mode  

Pressure / swivel angle control: Control enabled  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/7d70d7a86b0a5aa9b42561153d93ac5d5ce2740db26eecec67b9b94f30f86508.jpg  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/2891b0707fd4425211f3b9969cbd7a896aca22a0cb19e2a986ae28e9710fc85f.jpg  

## Control electronics for pump A4V..HS5(E) and SYDFED Calibration function  

Topics  

Pressure load cells Swivel angle sensor Valve calibration Leakage  

### Control electronics for pump A4V..HS5(E) and SYDFED Calibration function of pressure transducer  

# Prerequisites:  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/a563475486b6d93a0767543ffe7f00c29f202fe3c969619ffa4c0df6133cb39a.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Calibration function of valve  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/f77759de4c7081caf89f8cf4dd1316fb572e1afb6db01ac94d1b9e809bc904d3.jpg  

# Prerequisites:  

Pump drive motor on No oil flow in the system Active controller release from PLC  

Starting the calibration function  

Calibration function selection  

Pressure ratings for the calibration   
function Initial value 20 bar End value of desired system pressure 8 stages maximum  

### Control electronics for pump A4V..HS5(E) and SYDFED Calibration function of swivel angle offset  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/1132f8b62b119aef0e4f5daae3c8598fd87a1709c975c8cc053e0530904f6273.jpg  

# Prerequisites:  

Pump drive motor on No oil flow in the system Active controller release from PLC  

Starting the calibration function  

Calibration function selection  

### Control electronics for pump A4V..HS5(E) and SYDFED Calibration function of swivel angle factor  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/6e748daeffde584a9761b30a1822c5d8ee41bb70949de4efbe7bf35eed5d78d5.jpg  

# Prerequisites:  

Pump drive motor on No oil flow in the system Active controller release from PLC  

Starting the calibration function  

Calibration function selection  

### Control electronics for pump A4V..HS5(E) and SYDFED Calibration function of leakage  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/ef297d8012952b4baf4266ef946279456c46b202237ddfddbba49ca2143d1aa5.jpg  

# Prerequisites:  

Pump drive motor on No oil flow in the system Active controller release from PLC  

Starting the calibration function  

Calibration function selection  

The pressure command value for the calibration function should correspond to the desired system pressure  

## Control electronics for pump A4V..HS5(E) and SYDFED Status and diagnostic messages  

# Topics  

Status messages   
Diagnosis and status messages   
Oscilloscope  

### Control electronics for pump A4V..HS5(E) and SYDFED Status messages  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/9b1b097f30b778c05e268b83a13b44c76f63c1d8543f5e8d79a41c751a7b06e0.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Diagnosis and error messages  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/a9e419344d27c9d34f54656df96424032ad66c27ce0e78e84524f9b59ebecc03.jpg  

## Control electronics for pump A4V..HS5(E) and SYDFED Oscilloscope  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/1a41f0153ffd8d468db4c6f9e1dae7de39b0ca348ad7b6352fbd15af26dba92c.jpg  

# A@fNDAlectronics for pump A4V..HS5(E) and SYDFED  

Oscilloscope configuration  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/dfcbbea3cd3f7276fb41118983c682b8342ceb0451ab3bf20da5bd294799c47d.jpg  

# A@MDAlectronics for pump A4V..HS5(E) and SYDFED  

Oscilloscope configuration Trigger  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/4cb464f27e80e4c481cfce711854ce2387b82dcd76852d37c55f5aae0f0694da.jpg  

### A@MDAlectronics for pump A4V..HS5(E) and SYDFED Oscilloscope configuration  

#  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/0df25f7826014fb71f7c57ba1393736858419931297e84ef7747948b6dae2327.jpg  

### @fMDAlectronics for pump A4V..HS5(E) and SYDFED Recording  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/e246356de9634394f475fb0d2861518a82aac57bc206718615653e0666584c06.jpg  

### AGfNDAlectronics for pump A4V..HS5(E) and SYDFED Evaluating the recording  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/17dee30ab8a88f7f52749923014830b59beb26d60a63addf746729b641f61f55.jpg  

## Control electronics for pump A4V..HS5(E) and SYDFED Communication  

Topics:  

PROFINET properties PROFINET - switch-on Cyclic data exchange PROFINET device naming  

### Control electronics for pump A4V..HS5(E) and SYDFED PROFINET – Properties  

# Terms and abbreviations  

 Controller Field bus master is referred to as controller  Device Field bus slave is referred to as device  Station name Criterion for addressing a device  GSDML Device description comparable to GSD file (GSDML $=$ GSD Markup Language)  

# General properties  

 Ethernet according to IEEE 802.3   
 Transmission rate 100 Mbit/s   
 Data transmission via Ethernet cable (CAT5e copper)   
 Max. number of devices 128   
 Protocol types: PROFINET RT (real time) PROFINET IRT (interrupted real time)  

### Control electronics for pump A4V..HS5(E) and SYDFED PROFINET – Switch-on  

The PROFINET device switch-on with MultiEthernet interface has the following features:  

 Transmission rate: 100 Mbit/s   
 Supported topologies: Star and line (by means of integrated cut-through switch)   
 Minimum cycle time: 2 ms (parameterizable, PROFINET does not go by the slowest user)   
 Supported protocols: PROFINET RT   
 Addressing by the device name   
 Automatic assignment of IP addresses via DCP protocol  

(Discovery and Basic Configuration)  

### Control electronics for pump A4V..HS5(E) and SYDFED Cyclic data exchange  

 Cyclic data can be freely configured in the drive.   
 Besides command and actual values, it is also possible to exchange control and status words. For example, operating mode changes can be commanded by control words in the drive.   
 The maximum length of the cyclic real-time channel depends on the selected control communication.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/3fa7acf650fbb24316a44e3136a1bb00e043483bcf491059390531204a734ee5.jpg  

<html><body><table><tr><td colspan="2" rowspan="2">Axis mode Fieldbus diagnostics</td><td colspan="4">Operatingmode</td></tr><tr><td colspan="4">STANDBY:nofieldbussession</td></tr><tr><td colspan="2">Profile type</td><td colspan="2"></td><td></td><td>Activateprofile type</td></tr><tr><td colspan="2"></td><td colspan="2">Analog</td><td colspan="2"></td><td></td></tr><tr><td colspan="2">Data channel</td><td colspan="2">Real-time input (AT) Real-time output(MDT)</td><td></td><td></td><td></td></tr><tr><td>No.</td><td colspan="5">Configlist cyclicactual data channel</td><td>Lengthin bytes</td><td></td></tr><tr><td></td><td colspan="5">P-0-0115:Device control:Statusword</td><td></td><td>2</td></tr><tr><td>2 3</td><td colspan="5">P-0-2951:Pumpcontrollerstatusword</td><td></td><td>2</td></tr><tr><td>4</td><td colspan="5">S-0-0390:Diagnosticmessagenumber</td><td></td><td>4</td></tr><tr><td>5</td><td colspan="5">S-0-0809:Pressurefeedbackvalue</td><td>4</td><td></td></tr><tr><td>6</td><td colspan="5">S-0-0882:Swivelangleactualvalue</td><td>4</td><td></td></tr><tr><td></td><td colspan="5">S-0-0842:Flowfeedbackvalue</td><td></td><td></td></tr></table></body></html>  

### Control electronics for pump A4V..HS5(E) and SYDFED PROFINET – Cyclic data channel  

The cyclic data channel is classified as follows:  

 An axis-specific process data channel (real-time channel) which includes firmly agreed information which can be directly interpreted by the receiver.  

Data width: 15 parameters, 48 byte maximum, in both directions  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/1e7a88e2df9ac08d57a767500949c974b4b7797cc9f40ac24e45c8caabd6993f.jpg  

An (optional) device-specific parameter channel for reading and writing all parameters via PROFINET. The device-specific parameter channel does not comply with any real-time properties!  

### Control electronics for pump A4V..HS5(E) and SYDFED PROFINET – Data format  

The PROFINET protocol processes data in Motorola format. Drives operate in Intel format. This means that the words in a double word must possibly be swapped.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/7d3c5c2264b0fa58acf9f116c2fb296b4c19c11c0ff6cb290433dccae2636c51.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED PROFINET – Device naming  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/9082bb8f65801e7c547e9434991d291a682fad5c5db6ea44afbf0dc033af7360.jpg  

By naming the device, the IP address is automatically assigned.  

The station name may include the following characters:  

Small letters a - z   
Figures 0 - 9   
Special character dash -   
Capital letters are admissible but they will internally be changed to small letters.  

## A@MDAlectronics for pump A4V..HS5(E) and SYDFED HPC communication  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/ab4997c8a20aab557d4b7529f4083dde35e0cbaa8b320669243d642995cac3bd.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFED Analog inputs for A4.V.HS5  

<html><body><table><tr><td>Function</td><td>HPC</td><td>Analog input</td><td>VSO</td><td>VSG</td></tr><tr><td>Swivel angle command value S-0-0880</td><td>XG20 a3 / b3</td><td>Analog input 1</td><td>X</td><td>X</td></tr><tr><td>Pressure command value S-0-0800</td><td>XG20 a2 / b2</td><td>Analog input 2</td><td>X</td><td>X</td></tr><tr><td>Actual pressure value 1 (Pump B ) P-0-2940</td><td>XG20 a4 / b4</td><td>Analog input 3</td><td>X</td><td>X</td></tr><tr><td>Actual pressure value 2 (Pump A ) P-0-2941</td><td>XG20 a5 / b5</td><td>Analog input 4</td><td></td><td>X</td></tr><tr><td>Actual swivel angle value S-0-0882</td><td>XG21 a5 / b5</td><td>Fixed</td><td>X</td><td>X</td></tr></table></body></html>  

## Control electronics for pump A4V..HS5(E) and SYDFED Bus system  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/e1d01b9f7cdd0d5c84628608b6c69096d2301c22a4710806d1c49291ea22abd3.jpg  

### Control electronics for pump A4V..HS5(E) and SYDFEDBus parameter  HPC  PLC  

<html><body><table><tr><td></td><td></td><td></td></tr><tr><td>Field bus status word</td><td>P-0-4078</td><td>2 byte (1 word)</td></tr><tr><td>Pump control status word</td><td>P-0-2951</td><td>2 byte (1 word)</td></tr><tr><td>Actual swivel angle value</td><td>S-0-0882</td><td>4 byte (2 words)</td></tr><tr><td>Actual pressure value</td><td>S-0-0809</td><td>4 byte (2 words)</td></tr><tr><td>Diagnosis word</td><td>S-0-0390</td><td>4 byte (2 words)</td></tr><tr><td></td><td></td><td></td></tr></table></body></html>  

### Control electronics for pump A4V..HS5(E) and SYDFEDBus parameter HPC  PLC  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/2229dce53ac66f067c8ef28d2b463f5ab6cffc73e405ac932e5c26dd1f5613d2.jpg  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/33969c05bca69d7863c724e27f3c7b01fd273eaa8398acb3f0b24db58b672404.jpg  

<html><body><table><tr><td>Data channel</td><td>Real-time input (AT)</td><td>Real-time output (MDT)</td></tr></table></body></html>  

<html><body><table><tr><td>No.</td><td>Config list cyclic actual data channel</td><td>Lengthinbytes</td></tr><tr><td></td><td>P-0-4078:Field bus:Statusword</td><td>2</td></tr><tr><td>2</td><td>P-0-2951:Pump controller status word</td><td>2</td></tr><tr><td>Y</td><td>S-0-0809:Pressure feedbackvalue</td><td></td></tr><tr><td></td><td>S-0-0882:Swivel angleactual value</td><td></td></tr><tr><td>L</td><td>S-0-0390:Diagnosticmessage number</td><td></td></tr><tr><td></td><td></td><td></td></tr></table></body></html>  

### Control electronics for pump A4V..HS5(E) and SYDFEDBus parameter PLC  HPC  

<html><body><table><tr><td>Function</td><td>Parameter</td><td>Byte</td></tr><tr><td>Field bus control word</td><td>P-0-4077</td><td>2 byte (1 word)</td></tr><tr><td>Control word for pump control</td><td>P-0-2950</td><td>2 byte (1 word)</td></tr><tr><td>Swivel angle command value</td><td>S-0-0880</td><td>4 byte (2 words)</td></tr><tr><td>Pressure command value</td><td>S-0-800</td><td>4 byte (2 words)</td></tr><tr><td>Torque limitation, relative</td><td>P-0-2952</td><td>2 byte (1 word)</td></tr><tr><td>C79xx calibration command parameter</td><td>P-0-2990</td><td>2 byte (1 word)</td></tr><tr><td>Signal control word</td><td>S-0-0145</td><td>2 byte (1 word)</td></tr></table></body></html>  

### Control electronics for pump A4V..HS5(E) and SYDFEDBus parameter PLC  HPC  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/e58c4170910dfa6a846093ab8e24f092e8b6cfffc6821203aeaaa47d8f6e9012.jpg  

## Control electronics for pump A4V..HS5(E) and SYDFED P-0-2951 status word pump controller  

# Allocation Function  

Thisparameterrepresents thecurrentstatusofthepumpcontroller.  

# Structure  

<html><body><table><tr><td>Bit</td><td>Designation/function</td><td>Comment</td></tr><tr><td>0</td><td>statusof closed-looppressurecontrol 0:Closed-looppressure control is inactive</td><td></td></tr><tr><td></td><td>1:Closed-looppressure control is active Statusofclosed-loopswivelanglecontrol 0:Closed-loopswivelanglecontrolisinactive 1:Closed-loopswivelanglecontrolisactive</td><td></td></tr><tr><td></td><td>Statusof torquelimitation 0:Torque limitation is inactive 1:Torque limitation isactive</td><td></td></tr><tr><td></td><td>Statusofleakagecompensation 0:Leakage compensation is inactive 1:Leakagecompensation is active</td><td></td></tr><tr><td></td><td>Statusoffeedbackofactualpressurevaluederivative 0:Feedbackisinactive 1:Feedbackisactive</td><td></td></tr><tr><td>5-7</td><td>Reserved</td><td></td></tr><tr><td>8</td><td>Effective actualpressurevaluein theopencircuit 0:Pressure feedbackvalue 1isactive 1:Pressure feedbackvalue2isactive</td><td></td></tr><tr><td></td><td>Effectivepressurefeedbackvalueintheclosedcircuit 0:PressurefeedbackvalueBisactive 1:Pressure feedbackvalueAisactive</td><td></td></tr><tr><td>10-13</td><td>Reserved</td><td></td></tr><tr><td>14</td><td>Valvecommandvaluefeedforward 0:Feedforward is not active</td><td></td></tr><tr><td>15</td><td>1:Feedforward isactive Reserved</td><td></td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED  

### P-0-0115 device status word  

Thisparametercanbeused toread thedrive status(devicecontrol)independentlyof themastercommunicationuse  

See also Functional Description“Operation modes” See also Functional Description"Master communication” See also Functional DescriptionDrive Halt”  

# Structure  

The individual bitshave thefollowing significance:  

<html><body><table><tr><td>Bit</td><td>Designation/function</td><td>Comment</td></tr><tr><td>0</td><td>Drivereadyforoperation 0:Drivenotreadyforoperation 1:Drivereadyforoperation</td><td></td></tr><tr><td></td><td>Ready signal 1:Driveready(ready for poweroutput)</td><td></td></tr><tr><td>2</td><td>Drivewarning 1:Warning （class2diagnostics)is present</td><td></td></tr><tr><td>3</td><td>Statusofext.commandvalueprocessing(primaryop.mode+secondaryop.mode1-7) 0:Drive ignores（ext).commandvalue input 1:Drive follows（ext.)commandvalueinput</td><td></td></tr><tr><td></td><td>DriveHaltacknowledgment 1:Drive Halt is active andaxis is in standstill</td><td></td></tr><tr><td>5</td><td>Command changebit 0:No change in command status 1:Command status has changed</td><td></td></tr><tr><td>6</td><td>Statusofint.cimdval.processing(secondary op.modes8-15of PLc) 0:Driveignores（int.)commandvalue inputofPLC 1:Drive follows（int.)commandvalueinputofPLC</td><td></td></tr><tr><td>11/10/9/8Actualoperationmode</td><td>Operationmodeinitialized 1:Primaryop.modeor secondaryop.mode active and initialization completed,otherwise0</td><td></td></tr><tr><td></td><td>00oo:Primary operation mode isactive 00o1:Secondaryoperation mode1isactive 0111:Secondaryoperationmode7isactive 1000:Internal secondaryoperation mode 1isactive 1111:Internal secondary operationmode 8is active</td><td></td></tr><tr><td>12 13</td><td>Commandvaluereached activeoperationmodeis describedbelow.)</td><td></td></tr><tr><td>15/14</td><td>Driveerror 1:Drive error Readyfor operation</td><td></td></tr><tr><td></td><td>00:Control section/power sectionnotreadyfor operation(e.g.,drive error orphase2) 01:Control sectionready for operation(bb) 10:Control section andpowersectionreadyforoperation(Ab) 11:Drive with torque (AF)</td><td></td></tr></table></body></html>  

## Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

For all HydraulicDrives with pump control we offer the order option “variablespeed operation”. Variable-speed operation is a technology function, which is executed in the drive-internal MLD. For reasons of simplification, the HydraulicDrives DFED, HPC and HS5E are referred to as “pump controllers” in the following chapters.  

Step by step description for activating variable-speed operation   
Functional description of reals time mode   
Control-, status- and error word description   
Speed command frequency converter   
Parametrizing  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

For activating the technology function in the HPC the following step has to be carried out:  

Switch the HPC off and insert the SD card with the technology function into the memory card slot of the HPC. When switched on, the HPC reads the data from the SD card and recognizes that the technology function is to be activated. The status LED "MS" starts to blink alternating red and green. After the technology function was activated, the HPCbriefly switches all LEDs off and reboots. The technology function is then ready for operation.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/09512d8170282f1699939834507aaeef95eae54be50ccfc1114ea84a18543439.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

# Activating the MLD in the Indraworks DS dialog  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/7d22c835d47c0f18d9b44d5c4c4f12be9dc64ce108eb7376f59b48ac6f7c7615.jpg  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/a4bb3aff486137983bdbf51520bb19e7a9bb323e1b2d8e64dae1de780b963a6a.jpg  

Note: For updating the project treeit may be necessary to re-establish the connection to the device!  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

# Check for the correct version in the “Project information” dialog  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/d33d8a10d0d7ffd0637a98829dc9037d9608a38c057389666f59e941ce18283b.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

Activating the technology function at the SD-Card, for this enable signal must be false. After this make a reboot  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/78b0ec4d0b6e30cd9c06d32c5e87052122a2d193153be7484cc4e953814c7429.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

# Initialising of PLC – parameters by reset cold  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/7143187fa82f6baba0bfc9dc2d559dbe766d9f59aece131a081a9bf9f6db84e7.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

# Starting PLC by RUN button  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/abb054cc59483c2ff01df2d37d25cabdf317014e43b4da888d192e34be48eadf.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

# Controlling the corect version  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/4da9f8df8719dece53aa0aea012653a1db5dc43cfc94d92704dd2998597203cf.jpg  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/1e41abf2676a78513b06e55770a143c344ef3e7ba694ce1bf0c24fa695c610e8.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

Functional description of real-time mode   
The real-time mode is used for machines that have no cyclic operation. In the real-time mode, the optimum drive speed is calculated at all times and compared to the current speed. If a difference is detected between the two   
speeds, the setpoint speed is raised or lowered as required. As against the teach mode or the pump controller with fixed speed, in the real-time mode the speed adjustment in the case of major changes in flows also depends on the dynamics of the electric drive. To compensate for these lower dynamics, at least partially, various boost functions can be activated. All command values can be fed forward in analog form or via field bus.  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/b742dd9a65770c1a73ca4160605da5d0b06791fff5047e9e250bce30bc5af8e2.jpg  
DCH_RealtimeBetrieb en.des  

The optimum drive speed is calculated from the provision of the optimum swivel angle while motor overloading is avoided. The drive speed thus calculated is then considered in swivel angle command value processing and in pressure controller adaptation.  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

Controlling variable-speed operation Variable-speed operation is activated by means of bit 0 of control word DFEn/ HS5n (P-0-1370.0.0). Withdrawing bit 0 deactivates variable-speed operation, and the electric motor then runs again at constant maximum speed   
(P-0-2987.0.0). The selection between real-time (0) or teach mode (1) is   
made using bit 5.   
All bits can optionally be changed via  

digital inputs or via the field bus interface.  

<html><body><table><tr><td>Bit</td><td>Designation/function</td></tr><tr><td>0</td><td>Variable-speed operation ON(1)/ OFF(0)</td></tr><tr><td>4</td><td>Manual speed ON (1) / OFF(0)</td></tr><tr><td>5</td><td>Teach mode activated(1)/ Real-time mode activated (0)</td></tr><tr><td>8</td><td>Boost function p(diff) ON (1) / OFF (0)</td></tr><tr><td>9</td><td>Boost function swa(act) change ON (1) / OFF (0)</td></tr><tr><td>10</td><td>Boost function swa(diff) ON (1) / OFF (0)</td></tr><tr><td>12</td><td>Teach-in started ON (1) / OFF (0)</td></tr><tr><td>13</td><td>Sync set ON (1) / OFF (0)</td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED  

# Variable-speed operation = n-functionality  

The current status of variable-speed operation can be queried via the status word DFEn/HS5n P-0-1282.0.0 for   
diagnostic purposes. Warnings and   
erroneous   
states can be queried via P-0-1281.0.0 / P-0-1280.0.0.  

<html><body><table><tr><td>Bit</td><td>False</td><td></td></tr><tr><td>0</td><td>Variable-speed operation inactive</td><td>Variable-speed operation active</td></tr><tr><td>1</td><td>Real-timemodeactive</td><td>Teachmode active</td></tr><tr><td>2</td><td>No warning active</td><td>Atleastonewarningactive</td></tr><tr><td>3</td><td>Noerror active</td><td>Atleastoneerroractive</td></tr><tr><td>4</td><td></td><td>-</td></tr><tr><td>5</td><td></td><td></td></tr><tr><td>6</td><td></td><td>一</td></tr><tr><td>7</td><td>Boost function inactive</td><td>Boostfunctionactive</td></tr><tr><td>8</td><td>Ramp inactive</td><td>Ramp active</td></tr><tr><td>6</td><td>-</td><td></td></tr><tr><td>10</td><td></td><td>-</td></tr><tr><td>11</td><td>Speed suppression inactive</td><td>Speed suppression active</td></tr><tr><td>12</td><td>Derating inactive</td><td>Derating active</td></tr><tr><td>13</td><td>Manualspeedinactive</td><td>Manualspeedactive</td></tr><tr><td>14</td><td>Boostoffsetinactive</td><td>Boostoffsetactive</td></tr><tr><td>15</td><td>Teach-in not completed</td><td>Teach-in completed</td></tr><tr><td>16</td><td>Standby (partial load) inactive</td><td>Standby (partial load) active</td></tr><tr><td>17</td><td>Boostfunctionp(diff) inactive</td><td>Boost function p(diff) active</td></tr><tr><td>18</td><td>Boost function swa(act) change inactive</td><td>Boost function swa(act) change active</td></tr><tr><td>19</td><td>Boost function swa(diff) inactive</td><td>Boost function swa(diff) inactive</td></tr><tr><td>20</td><td></td><td></td></tr><tr><td>21</td><td>Torque limit inactive</td><td>Torque limit inactive</td></tr><tr><td>22</td><td>Overloadfield-weakeningrangeinactive</td><td>Overloadfield-weakeningrangeactive</td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED  

# Variable-speed operation = n-functionality  

<html><body><table><tr><td></td><td>Warning</td><td>P-0-1281</td><td>Error</td><td>P-0-1280</td><td></td></tr><tr><td>Condition</td><td>Code</td><td>Bit</td><td>Code</td><td>Bit</td><td>Textoutput</td></tr><tr><td>AF=0</td><td>B5201</td><td>0</td><td></td><td></td><td>Variable-speedoperationinactive</td></tr><tr><td>P-0-1376 =0</td><td>B5202</td><td>1</td><td></td><td></td><td>P-0-1376=0:Invalid inputvalueforspeedrampup</td></tr><tr><td>P-0-1377 =0</td><td>B5203</td><td>2</td><td></td><td></td><td>P-0-1377=0:Invalidinputvalueforspeedramp down</td></tr><tr><td>P-0-1379 =0</td><td>B5205</td><td>4</td><td></td><td></td><td>P-0-1379=0:Thresholdforpressurediff.boost"0" leadstopermanentlyactiveboostfunction</td></tr><tr><td>P-0-1311invalid</td><td>B5207</td><td>6</td><td>D5207</td><td>6</td><td>ConfigurationparameterenteredinlistP-0-1311is invalid</td></tr><tr><td>P-0-1311.11=0</td><td>B5208</td><td>7</td><td></td><td></td><td>P-0-1311.11=0:Thresholdforboostswa(diff)"0" leadstopermanentlyactiveboostfunction</td></tr><tr><td>P-0-1311.9=0</td><td>B5209</td><td>8</td><td></td><td></td><td>P-0-1311.9 0:Thresholdfor boost swa(act) change"o"leadstopermanentlyactiveboostfunc tion</td></tr><tr><td>P-0-1320 P-0-2987</td><td>B5103</td><td>13</td><td>D5103</td><td>13</td><td>P-0-1320 > P-0-2987: Minimum speed exceeds maximumdrivespeed</td></tr><tr><td>P-0-1328-P-0-1329 <P-0-1320 P-0-1328</td><td>B5106</td><td>15</td><td></td><td></td><td>P-0-1328 -P-0-1329<P-0-1320:LowersuppreS sionwindowlimitfallsbelowminimumdrivespeed</td></tr><tr><td>P-0-1329 P-0-2987</td><td>B5107</td><td>16</td><td></td><td></td><td>P-0-1328+P-0-1329<P-0-2987:Uppersuppres- sionwindowlimitexceedsmaximumdrivespeed</td></tr><tr><td>P-0-1320 P-0-1385</td><td>B5301</td><td>20</td><td>D5301</td><td>20</td><td>P-0-1320<P-0-1385:Minimumpartialspeedload ishigherthanminimumdrivespeed</td></tr><tr><td>P-0-2944 P-0-1321</td><td>B5302</td><td>21</td><td></td><td></td><td>P-0-2944>P-0-1321:Nominalspeedis greater thansynchronousspeed</td></tr><tr><td>TSample<=0</td><td>B5310</td><td>25</td><td></td><td></td><td>Samplingtime"<=o"notpermitted</td></tr><tr><td>Wrongfirmwarever- sion</td><td>B5313</td><td>28</td><td>D5313</td><td>28</td><td>Errorinversioncheck-firmwareistoooldforthis n-functionversion</td></tr><tr><td>Tsample cannot be read</td><td>B5314</td><td>29</td><td>D5314</td><td>29</td><td>UnabletoreadtaskcyclewhenthePLCisbooting</td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

Speed command converter P-0-1270.0.0  

In variable-speed operation, the speed command value for the converter is output in parameter P-0-1270.0.0. This speed command value can be transmitted to the converter via field bus communication or an analog output. The example below shows the configuration of the analog output for analog speed command value transmission.  

<html><body><table><tr><td>ParameterIDN</td><td>Designation</td><td>Valuerange</td><td>Unit</td></tr><tr><td>P-0-1270.0.0</td><td>Speed command converter</td><td>0.0 + 6000.0</td><td>1/min</td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED  

# Variable-speed operation = n-functionality  

With analog speed command value provision the analog input in the converter has to be configured to the same speed value.In addition, via offset and the signal range, the speed value that arrives in the converter can be matched with the input value that is issued by the pump controller. This allows drifts in the value ranges to be compensated for that are caused by analog signal transmission  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/1d6600a9893391c64a9244aaba308a0e26ed91abe8a6f06a04c9efd6cb66f535.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED  

# Variable-speed operation = n-functionality  

The individual parameters described in this chapter can be accessed via the overview dialog of variable-speed operation “Sytronix" (DFEn, HS5n). By clicking the button "Basic settings Sytronix" you get to the dialog, in which you can make the essential basic settings of variable-speed operation. The links in this dialog lead to further subdialogs, in which you can configure detailsand supplementary functions of variable-speed operation. With the buttons"Next" and "Previous" you can show or hide extended settings in the parameterizationdialogs.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/0cc5d968baebf8c80173b185cf9827ff48e6571fe2b82b28ac42f13e991502f3.jpg  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/5661e6266bd1e9d3f53f126a548ae5021d8fc1bcb73d308cb75b4d6c03dbe69b.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

Dialog Basic settings Sytronix (DFEn, HS5n)  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/76cc3cff2e7da969409781830f18788bbb8dbc872c8ba9f26b80d67f3a067cf3.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

# Parameters of the motors  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/71f37fd755b149316d3494ce6b6d37112d791debb732d86f798a629548f246de.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED  

# Variable-speed operation = n-functionality  

# Nominal power motor P-0-1381.0.0  

The nominal motor power is required for various internal calculations, e.g.loading of the asynchronous motor, by the pump controller. The nominal powercan be read from the nameplate.  

<html><body><table><tr><td>ParameterIDN</td><td>Designation</td><td>Defaultvalue</td><td>Value range</td><td>Unit</td></tr><tr><td>P-0-1381.0.0</td><td>Nominal powermotor</td><td>7.5</td><td>0.1:-200.0</td><td>kW</td></tr></table></body></html>  

# Motor nominal speed P-0-2944.0.0  

To be able to calculate the slip characteristic curve of the asynchronous motorthe nominal speed at nominal loading of the asynchronous motor has tobe known. The nominal speed can be read from the nameplate of the asynchronousmotor.  

<html><body><table><tr><td>ParameterIDN</td><td>Designation</td><td>Defaultvalue</td><td>Valuerange</td><td>Unit</td></tr><tr><td>P-0-2944.0.0</td><td>Motornominal speed</td><td>1500</td><td>100-6000</td><td>1/min</td></tr></table></body></html>  

Maximum drive speed P-0-2987.0.0  

The speed can be scaled using parameter "P-0-2987.0.0, Maximum drivespeed". In the case of analog command value provision this corresponds to $10\vee$ ( $100\%$ ) $=$ maximum value when the drive speed is calculated.  

<html><body><table><tr><td>ParameterIDN</td><td>Designation</td><td>Default value</td><td>Value range</td><td>Unit</td></tr><tr><td>P-0-2987.0.0</td><td>Maximum drivespeed</td><td>1500</td><td>100-6000</td><td>1/min</td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

# Time constant motor model P-0-1371.0.0  

To compensate for the following error (dynamic error) of an electric motor, amotor model is activated for the variable-speed pump control. This motormodel calculates the speed deviation of the motor when the speed changes   
and considers this error in the calculation of the speed command value. Theactual speed value calculated by the motor model is written to parameter   
"P-0-2993.0.0, Current drive speed" to ensure a correct calculation of the internal   
swivel angle command value.  

<html><body><table><tr><td>ParameterIDN</td><td>Designation</td><td>Defaultvalue</td><td>Value range</td><td>Unit</td></tr><tr><td>P-0-1371.0.0</td><td>Time constant motormodel</td><td>0.1</td><td>0.002-10.000</td><td>S</td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

Torque limitation motor P-0-1383.0.0  

When the speed is reduced while the hydraulic power remains unchanged,the current motor torque is accordingly larger. If, while the speed is reduced,the motor is loaded with a torque higher than the nominal torque, the power loss increases significantly in the asynchronous motor. By means of parameterP-0-1383.0.0 the maximum torque in $\%$ referred to the nominal torque ofthe motor can be provided for variable-speed operation. Given the drive motor has its optimum efficiency at $80\%$ of the nominal torque, the torque limitationof the drive motor can be set to $80\%$ , if the motor is to be operated withinits optimum efficiency range. If, however, the motor is to be subjected to up to a 1.5 fold overload, the value has to be set to $150\%$ .Torque limitation can even be limited to a value of less than $100\%$ , if, due toan additional pump at the motor shaft (e.g. cooling/filtration pump), it is impossible to use the full drive power of the motor for the control pump.  

<html><body><table><tr><td>ParameterIDN</td><td>Designation</td><td>Defaultvalue</td><td>Valuerange</td><td>Unit</td></tr><tr><td>P-0-1383.0.0</td><td>Torquelimitationmotor</td><td>100.0</td><td>1.0-350.0</td><td>%</td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

Derating of electric drive P-0-1326.0.0, P-0-1327.0.0  

Asynchronous motors are usually operated with an integrated fan. As thespeed is reduced, the cooling capacity of the integrated fan falls accordingly.This results in the fact that at continuingly low speeds the nominal torque cannot be maintained since this would excessively overheat the motor.In addition, on some motors, especially asynchronous motors, the energy efficiencyat nominal torque falls at lower speeds so that it would be energetically more favorable to operate the motor at slightly higher speed and lowertorque. In this case, derating can be activated at lower speeds. The speedlimit, at which derating is to be activated can be set by means of parameter P-0-1327.0.0. Parameter P-0-1326.0.0 can be used to enter the theoreticaltorque at speed "zero". This value is to be entered in $\%$ of the nominal torque.Should an external fan be used for the asynchronous motor or derating be deactivated, the value for P-0-1326.0.0 can be set to $100\%$ .  

<html><body><table><tr><td>ParameterIDN</td><td>Designation</td><td>Default value</td><td>Valuerange</td><td>Unit</td></tr><tr><td>P-0-1326.0.0</td><td>Deratingreduced torquevalueatOrpm</td><td>20.0</td><td>0.0-100.0</td><td>%</td></tr><tr><td>P-0-1327.0.0</td><td>Speed limitfor derating torque</td><td>800</td><td>1-6000</td><td>1/min</td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/1f79a18dba04f7e1d226521ef426f897aae6ab64113a1d56127b1e7849d50d53.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

# Field-weakening operation  

For some applications it may be useful to briefly activate higher speeds than the synchronous speed of the motor. For this the asynchronous motor is operatedin the field-weakening range. In this context it must be noted that in the field-weakening range the available motor torque is reduced while the power loss increases. Moreover, care must be taken that the permissible maximum speeds of the pump and the motor are not exceeded. The course of nominal torque Mnom of an asynchronous motor in the speed range from 0to 2100 1/min is shown with a solid line in "Example of field-weakening operation" on page 25. The dotted line represents the course of torque limitation that is required when derating and field-weakening operation are active to protect the motor against overloading and breaking down. For activating field-weakening operation of the motor, the maximum drive speed P-0-2987.0.0 has to be greater than the synchronous speed P-0-1321.0.0 as shown in "Example of field-weakening operation". In the converter the corresponding settings have to be made too in order that the selected maximum drive speed can also be provided by the converter. Further notes can be found in the operating instructions of the converter.  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

# Synchronous rotation speed P-0-1321.0.0  

Parameter P-0-1321.0.0 specifies the synchronous speed of the drive. The synchronous speed is determined by the mains frequency and the number of terminal pairs. With $50\mathsf{H z}$ mains and a 4-pin motor, the synchronous speed is 1500 1/min. To operate a motor exclusively in the basic speed range, the synchronous rotation speed P-0-1321.0.0 and the maximum drive speed P-0-2987.0.0 must have the same value. Within the basic speed range from 0 to synchronous rotation speed the torque limitation motor P-0-1383.0.0 is used for calculating the speed. If the maximum drive speed P-0-2987.0.0 is set to a value greater than the synchronous speed P-0-1321.0.0, the motor can be operated within the basic speed range and the field-weakening range. For speeds higher than the synchronous speed in field-weakening operation, the permissible torque can be limited with parameter P-0-1384.0.0. in order to prevent the motor from overloading.  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

# Permissible torque at maximum speed P-0-1384.0.0  

In order to activate torque limitation within the field weakening range as shown in fig. 3-9 "Example of field-weakening operation" on page 25, the permissible torque at maximum speed P-0-1384.0.0 has to be less than the torque limitation motor P-0-1383.0.0.  

The limitation is realized as illustrated in the graphic with the help of exemplary values with 1/n2 of $150\%$ at 1500 1/min to $110\%$ at 2100 1/min. Parameters P-0-1383.0.0 and P-0-1384.0.0 are percentage values and refer to the nominal torque Mnom of the asynchronous motor. The nominal torque in field-weakening range MFWR follows a hyperbolic profile with 1/n.  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/c8ad6f2d519b7464776efe640751f36bd4bbdd0af2c744aa7c92f83f38c9a743.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

<html><body><table><tr><td>P-0-1327.0.0,Rotationspeedforderating torque -800[1/min]</td><td>P-0-1326.0.Deratingreducedtorquevalueat0rpm 20 [%]</td></tr><tr><td>P-0-1321.0.0Synchronousrotationspeed-1500[1/min]</td><td>P-1383.0.0Torque limitationmotor-150[%]</td></tr><tr><td>P-0-2987.0.0Maximumdrivespeed-2100[1/min]</td><td>P-1384.0.0Permissibletorqueatmax.speed 110 [%]</td></tr><tr><td>PNem[kW].9550 MNem[Nm]=</td><td>[kW].9550 MFWR[Nm]=</td></tr><tr><td>nNemm[1/ min]</td><td>n[1/min]</td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

# Field-weaking operation  

<html><body><table><tr><td>ParameterIDN</td><td>Designation</td><td>Default value</td><td>Valuerange</td><td>Unit</td></tr><tr><td>P-0-1321.0.0</td><td>Synchronousrotation speed</td><td>1500</td><td>1-6000</td><td>1/min</td></tr><tr><td>P-0-1384.0.0</td><td>Permissible torque at max. speed</td><td>100.0</td><td>0.0-250.0</td><td></td></tr></table></body></html>  

# Gain slip compensation P-0-1311.0.0.10  

Since the slip of the asynchronous motor has an effect on the actual displacement, the pump controller features an additional function to compensate for the slip of an asynchronous motor. The gain of this slip compensation can be adapted by means of parameter P-0-1311.0.0.10. If the converter features an integrated slip compensation this value has to be reduced or set to 0.  

<html><body><table><tr><td>ParameterIDN</td><td>Designation</td><td>Default value</td><td>Value range</td><td>Unit</td></tr><tr><td>P-0-1311.0.0.10</td><td>Gain slip compensation</td><td>100.0</td><td>0.0 - 150.0</td><td>%</td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

# Parameters of speed calculation  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/c61bd05404da9886aac3e517222e8a6ce939e2d28546a1dff64731909563e837.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

Minimum speed P-0-1320.0.0 / Minimum speed stand-by P-0-1385.0.0 / threshold, from which on partial load is active referred to nominal power P-0-1311.0.0.4  

By means of parameter P-1320.0.0 the minimum speed can be determined. For drives, which are operated with U/f characteristic curve, the manufacturers specify a minimum speed, up to which the nominal torque is briefly available. For partial load operation of the machine, a second, minimum speed standby P-0-1385.0.0 (“minimum speed under partial load”) can be specified. This speed limit is active, when the torque in the cycle is below $3\%$ (P-0-1311.0.0.4) of the nominal torque. Due to the second minimum speed it is, for example, possible to reduce the magnetization of the asynchronous motor in partial load operation of the machine in order to reduce power losses. More details can be found in the data sheet of the motor and converter manufacturer.  

<html><body><table><tr><td>ParameterIDN</td><td>Designation</td><td>Defaultvalue</td><td>Valuerange</td><td>Unit</td></tr><tr><td>P-0-1320.0.0</td><td>Minimumrotationspeed</td><td>300</td><td>50-2000</td><td>1/min</td></tr><tr><td>P-0-1385.0.0</td><td>Minimumspeedstand-by</td><td>250</td><td>50-2000</td><td>1/min</td></tr><tr><td>P-0-1311.0.0.4</td><td>Powerthresholdstandbyactive</td><td>3</td><td>0-100</td><td>%</td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

# Ramp time / speed change (P-0-1376.0.0, P-0-1377.0.0)  

The ramp slope for speed ramps can be adjusted by means of parameters P-0-1376.0.0 and P-0-1377.0.0. The ramp slope is set in 1/min/s. The acceleration time should always be determined taking into account the possible minimum acceleration time of the drive. The deceleration time should be selected so that the motor is not actively decelerated and thus does not recover energy.In order not to affect the control behavior of the pump controller with thespeed adjustment, a delay (P-0-1311.0.0.7) and a tolerance threshold can be specified for the speed adjustment (P-0-1311.0.0.1).  

<html><body><table><tr><td>ParameterIDN</td><td>Designation Speedrampup</td><td>Defaultvalue 1875</td><td>Valuerange 0-10000</td><td>Unit 1/min/s</td></tr><tr><td>P-0-1376.0.0 P-0-1377.0.0</td><td>Speedrampdown</td><td>650</td><td>10000</td><td>1/min/s</td></tr><tr><td>P-0-1311.0.0.7</td><td>Delaydecelerateramp</td><td>0.000</td><td>0.000-10.000</td><td>S</td></tr><tr><td></td><td></td><td></td><td></td><td>1/min</td></tr><tr><td>P-0-1311.0.0.1</td><td>Speedloweringthreshold</td><td>30</td><td>0-500</td><td></td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

Filter for rounding the speed command value (P-0-1311.0.0.2,P-0-1311.0.0.3)  

Due to the noise on the analog actual values of swivel angle and pressure, oscillations may occur on the speed command value. This oscillation may be dampened with the help of a filter for rounding the speed command value.  

<html><body><table><tr><td>Parameter IDN</td><td>Designation</td><td>Default value</td><td>Valuerange</td><td>Unit</td></tr><tr><td>P-0-1311.0.0.2</td><td>PT1ramp up（filter time constant forrounding the increasing speed command value)</td><td>0.008</td><td>0.002 -1.000</td><td>S</td></tr><tr><td>P-0-1311.0.0.3</td><td>PT1 ramp down (filter time constant tfor rounding the falling speed commandvalue)</td><td>0.2</td><td>000.2 - 1.000</td><td>S</td></tr></table></body></html>  

Speed suppression window (P-0-1328.0.0, P-0-1329.0.0)  

In order to minimize any possibly existing points of resonance a suppression window may be defined. Speed command values within the suppression window are not continuously activated. If the optimized speed is within the defined window, the upper limit of the speed suppression window is to be aimedat.  

<html><body><table><tr><td>ParameterIDN</td><td>Designation</td><td>Defaultvalue</td><td>Valuerange</td><td>Unit</td></tr><tr><td>P-0-1328.0.0</td><td>Speed suppression window center</td><td></td><td>0-6000</td><td>1/min</td></tr><tr><td>P-0-1329.0.0</td><td>Speed suppression window breath</td><td></td><td>0-1000</td><td>1/min</td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/3726c6fc1b2e5c4ebdc88344408acc69c7a9af45de003d431b5178ad543e8609.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

Manual speed selection value (P-0-1370.0.0, P-0-1316.0.0, P-0-1317.0.0)  

The real-time mode offers two possibilities of influencing the speed manually by entering values. While variablespeed operation is active (P-0-1370.0.0 Bit 0 set), a further minimum speed may be set via parameter P-0-1316.0.0. This function can be used shortly before a large flow requirement, e.g. start of a cylinder after standby, to raise the speed and thus to significantly increase the dynamics of the pump controller. When variable-speed operation is switched off (P-0-1370.0.0 bit 0 cleared), a manual speed can be approached by means of P-0-1317.0.0, e.g. for the setup mode. In the factory settings, the value 0 rpm is entered for parameters P-0-1316.0.0 and P-0-1317.0.0. The manual provision of speed values can be activated via bit 4 of parameter P-0-1370.0.0. This bit can be activated via both the field bus interface and a freely configurable digital input. In the factory settings, bit 4 for the manual  

speed selection state of bit 4.  

<html><body><table><tr><td>Bit</td><td>Designation/function</td><td rowspan="3">ectionisalsodeactivated, irrespectiveofth</td></tr><tr><td></td><td>Variable-speed operation ON(1) / OFF (0)</td></tr><tr><td></td><td>Manual speed ON (1) / OFF (0)</td></tr></table></body></html>  

<html><body><table><tr><td>ParameterIDN</td><td>Designation</td><td>Defaultvalue</td><td>Valuerange</td><td>Unit</td></tr><tr><td>P-0-1316.0.0</td><td>Manual min.rotation speed-real-time on</td><td></td><td>10-6000</td><td>1/min</td></tr><tr><td>P-0-1317.0.0</td><td>Valuemanualspeed-real-timeoff</td><td></td><td>10-6000</td><td>1/min</td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

# Boost functions and feedforward of speed command value (P-0-1317.0.0, P-0-1311.0.0.8, P-0-1311.0.0.9, P-0-1311.0.0.11, P-0-1311.0.0.12, P-0-1378.0.0, P-0-1379.0.0)  

The boost functions can be used in real-time operation to improve the dynamics of the system when increasing the speed. While boost is activated, the speed command value is raised according to the maximum speed ramp. For this, the boost functions evaluate various process variables in pressure and swivel angle control. The individual boost functions can be activated via bits 8-10 of parameter P-0-1370.0.0. With the factory setting, all boost functions  

are deactivated. The most common boost function is p(diff), because it can be used to achieve a clearly faster reaction of the pressure controller to pressure breakdowns.  

<html><body><table><tr><td>Bit</td><td>Designation/function</td></tr><tr><td>8</td><td>Boost function p(diff) ON (1)/ OFF(0)</td></tr><tr><td>9</td><td>Boost functionswa(act) change ON (1) / OFF(0)</td></tr><tr><td>10</td><td>Boost function swa(diff) ON (1) / OFF (0)</td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

# Boost p(diff) pressure controller (P-0-1378.0.0, P-0-1379.0.0)  

This function monitors the magnitude of the pressure breakdown in pressure control. When a defined threshold value (P-0-1379.00) is exceeded, the boost is activated. While the boost is activated, the error from this pressure differential is multiplied with a gain of (P-0-1378.0.0) and added to the speed command value as feedforward value. This boost is active only with active pressure controller.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/a1458dabaf3b69a0c3fd9e36e0fea6f255446d5bd2a06aa1228ca196f6883d61.jpg  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

Boost actual swivel angle value change (P-0-1311.0.0.8, P-0-1311.0.0.9)  

This function monitors the change in the actual swivel angle value. When the change rate exceeds a defined threshold value (P-0-1311.0.0.9), the boost is activated. To smooth the swivel angle change rate an additional low pass with defined filter time constants (P-0-1311.0.0.8) can be applied.  

# Boost swa(diff) swivel angle controller (P-0-1311.0.0.11, P-0-1311.0.0.12)  

This function monitors the magnitude of the control deviation swa(diff) in swivel angle control. When a defined threshold value (P-0-1379.0.0.11) is exceeded, the boost is activated. While the boost is activated, the error from this swivel angle differential is multiplied by a gain (P-0-1311.0.0.12) and added to the speed command value as feedforward value. This boost is only active with active swivel angle controller.  

<html><body><table><tr><td>ParameterIDN</td><td>Designation</td><td>Default value</td><td>Valuerange</td><td>Unit</td></tr><tr><td>P-0-1378.0.0</td><td>Gain for intrusion p(diff) boost</td><td>U</td><td>0.0-250.0</td><td>%</td></tr><tr><td>P-0-1379.0.0</td><td>Threshold for pressure diff. boost</td><td>5</td><td>1-315</td><td>bar</td></tr><tr><td>P-0-1311.0.0.8</td><td>Filter delay time -derivation swa(act)</td><td>0.01</td><td>0.000-0.100</td><td>S</td></tr><tr><td>P-0-1311.0.0.9</td><td>Threshold for change swa(act) boost</td><td>400</td><td>0-4000</td><td>%/s</td></tr><tr><td>P-0-1311.0.0.11</td><td>Threshold for swa(diff) boost</td><td>5</td><td>0.0 -100.0</td><td>%</td></tr><tr><td>P-0-1311:0.0:12</td><td>Gain for intrusion swa(diff) boost</td><td></td><td>0.0 -250.0</td><td>%</td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/5adebde67c90a98552be3c67074c8ccff3e78cc08344ca3e4fea70eb91a80dad.jpg  

# Optimum swivel angle (n-var) P-0-1372.0.0  

In variable-speed operation, the optimum swivel angle can be provided via parameter P-0-1372.0.0. The pump controller reduces the speed until this optimum swivel angle is reached to displace the required amount of fluid. Generally, the efficiency of the pump improves as the swivel angle increases. In order to minimize power losses in variable-speed operation, the speed should be reduced until the swivel angle comes close to its maximum. To get a sufficient control reserve for the swivel angle controller, the optimum is between $65\%$ and $95\%$ (depending on system).  

<html><body><table><tr><td>ParameterIDN</td><td>Designation</td><td>Defaultvalue</td><td>Value range</td><td>Unit</td></tr><tr><td>P-0-1372.0.0</td><td>Optimum swivel angle (n-var)</td><td>70.0</td><td>50.0-98.0</td><td>%</td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

# Conversion of swivel angle command value (P-0-2950.0.0 Bit 4)  

In the operation mode of pressure/swivel angle control, the box “Activation ofconversion of internal swivel angle command value related to drive speed” has to be checked, if the given swivel angle command value refers to the maximum drive speed. In this case, the selected swivel angle command value is converted via this function according to the current drive speed.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/98c7e890ab67c52f9e1ed664208cd102f07ef2e74352f9d16348594432490ae7.jpg  

In the operation mode of pressure/flow control, this box needs not to be checked, since here the flow command value in l/min is automatically converted internally into the swivel angle command value in $\%$ using the current drive speed.  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

# Pump displacement volume P-0-2943.0.0  

For variable-speed operation the pump controller needs to know the size of the main pump, to which the highresponse valve of the pump control is mounted. In the case of several closed-loop controlled pumps (pressure controller of master/slave system), the sum of all control pumps which displace fluid into the hydraulic system is to be entered. This value is already queried within the framework of initial parameterization of the pump controller.  

<html><body><table><tr><td>ParameterIDN</td><td>Designation</td><td>Default value</td><td>Value range</td><td>Unit</td></tr><tr><td>P-0-2943.0.0</td><td>Pump displacement volume</td><td>100.0</td><td>0.1- 6553.3</td><td>cm3</td></tr></table></body></html>  

Nominal size additional pump P-0-1330.0.0  

In the case of a regenerative combination with one or several pumps, the size of the additional fixed displacement pump has to be entered additionally in parameter P-0-1330.0.0. If several fixed displacement pumps are to be used, the sum of all control pumps which displace fluid into the hydraulic system is to be entered. In case that only one main pump or only a master/slave pressure controller with control pumps is used, the value "zero" has to be entered in P-0-1330.0.0.  

<html><body><table><tr><td>ParameterIDN</td><td>Designation</td><td>Defaultvalue</td><td>Valuerange</td><td>Unit</td></tr><tr><td>P-0-1330.0.0</td><td>Nominalsizeadditionalpump</td><td></td><td>10.0-356.0</td><td>cm3</td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

Adaptation of pressure controller  

https://d3d2iaoi1ibop8.cloudfront.net/Output/HTP-PC_2021-04_DCCN_EN/images/eb6c4fbc2a4e62bbc961381ec517688978f88eef259bbb6b88f63ec2114172f0.jpg  

DCH_Adaption_Druckregler_EN.des  

# Input of characteristic curve for adapting the PD controller  

At reduced speed, the control behavior of the pressure control of a control pump differs from that at nominal speed. By adapting the PD pressure controller the pump controller can feature a largely similar control behavior, which is independent of the current speed.  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

Lower barrier adaption proportional term P-0-1311.0.0.13 / P-0-1311.0.0.16  

These values can be used for setting the lower limit value of the characteristic curve. Below this speed limit the PD pressure controller is no longer adapted.  

Upper barrier adaption proportional term P-0-1311.0.0.14 / P-0-1311.0.0.17  

These values can be used for setting the upper limit value of the characteristic curve. Above this speed limit the PD pressure controller is no longer adapted.  

Gain lower barrier adaption proportional term P-0-1311.0.0.15 /P-0-1311.0.0.18  

By means of P-0-1311.0.0.15 and P-0-1311.0.0.18 the gain factor for the lower speed limit can be set. The gain factor for the upper limit speed is firmly set to 1.0. Between the upper and the lower speed limit the gain factor is linearly increased depending on the speed. The example below therefore results in the following course of the gain factor. From speed 0 - 250 1/min a gain factor of 2.15 is active in the adaptation of the P-controller. Between 250 and 1200 1/min the gain factor falls linearly to 1.0. Above 1200 1/min, the gain factor is constant at 1.0.  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

<html><body><table><tr><td>ParameterIDN</td><td>Designation</td><td>Defaultvalue</td><td>Valuerange</td><td>Unit</td></tr><tr><td>P-0-1311.0.0.13</td><td>Lowerbarrieradaptionproportionalterm</td><td>250</td><td>10-6000</td><td>1/min</td></tr><tr><td>P-0-1311.0.0.14</td><td>Upperbarrieradaptionproportional term</td><td>1200</td><td>10-6000</td><td>1/min</td></tr><tr><td>P-0-1311.0.0.15</td><td>Gainlowerbarrieradaptionproportionalterm</td><td>2.15</td><td>0.00-10.00</td><td></td></tr><tr><td>P-0-1311.0.0.16</td><td>Lowerbarrieradaptionderivativeterm</td><td>250</td><td>10-6000</td><td>1/min</td></tr><tr><td>P-0-1311.0.0.17</td><td>Upperbarrieradaptionderivativeterm</td><td>1200</td><td>10-6000</td><td>1/min</td></tr><tr><td>P-0-1311.0.0.18</td><td>Gainlowerbarrieradaptionderivativeterm</td><td>3.20</td><td>0.00-10.00</td><td></td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

# Factor disturb. feedforward pressure controller (P-0-1380.0.0)  

Any change in speed acts like an external disturbance variable. To compensate for this disturbance it is possible to feed forward an additional factor, which is calculated depending on the change in speed, to the controller output of the pressure controller. This factor can be scaled via parameter P-0-1380.0.0.  

<html><body><table><tr><td>ParameterIDN</td><td>Designation</td><td>Defaultvalue</td><td>Valuerange</td><td>Unit</td></tr><tr><td>P-0-1380.0.0</td><td>Factor disturb. feedfor- ward pressure control- ler</td><td></td><td>0.0 - 250.0</td><td>%</td></tr></table></body></html>  

# Control electronics for pump A4V..HS5(E) and SYDFED Variable-speed operation = n-functionality  

Reserve for revving up the motor at low speed - breakdown protection With the help of torque limitation of the pump you can ensure a torque reserve in order to be able to rev up the motor optimally even at low speeds. In addition, this reserve acts as breakdown protection at low speeds. This is required, because at 300 1/min the breakdown torque is $450\%$ of the nominal torque and the motor could thus be easily stalled at low speeds. At higher speeds, this torque reserve allows faster speeding up and hence a better speed increase behavior of the pump control.  

## Control electronics for pump A4V..HS5(E) and SYDFED Conclusion  