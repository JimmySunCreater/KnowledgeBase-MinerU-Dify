# Axial Piston Variable Pump A4VSO  

Series 1, 2 and 3  

## Operating Instructions  

RE 92050-01-B/03.08 Replaces: 03.05 English  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/9ef52f7a037dbbb5b1ddf2514828a741b1091c209f08015dba8a767386be38f2.jpg  

The data specified above only serve to describe theproduct.Nostatementsconcerningacertain condition or suitability for a certain application can be derived from our information. The information given does not release the user from the obligation of own judgment and verification. It must be remembered that our products are subject to a natural process of wear and aging.  

$\circledcirc$ This document, as well as the data, specifications and other information set forth in it, are the exclusive property of Bosch Rexroth. It may not be reproduced or given to third parties without its consent.  

An example configuration is shown on the title page. The delivered product may, therefore, differ from the product which is pictured.  

The original operating instructions were created in the German language.  

## Contents  

### 1 About this document.  

1.1 Related documents   
1.2	 Abbreviations used..  

### 2	 General safety instructions..  

2.1	 Intended use.. 6   
2.2 Improper use. 6   
2.3 Personnel qualifications.. .6   
2.4	 Safety instructions in this document.. 7   
2.5	 Adhere to the following instructions.. 7   
2.6	 Operator's obligations... 9  

### 3Delivery contents.  

### 4 Product description  

4.1  Performance description. 11   
4.2	 Device description... 11   
4.3	 Product identification.. 22  

### 5Transport and storage.  

5.1  Transporting the axial piston unit 23   
5.2 Storing the axial piston unit. .24  

### 6 Assembly. 26  

6.1 Unpacking.. 26   
6.2	 Installation conditions.. 26   
6.3	 Installation position..... .28   
6.4	 Assembling the axial piston unit.. 31  

### 7 Commissioning. 2  

7.1	 First commissioning.... 43   
7.2  Recommissioning after downtime. 45   
7.3 Running-in phase. .46  

### 8 Operation.  

### 9 Maintenance and repair. 48  

9.1  Cleaning and care 48   
9.2	 Inspection.... 48   
9.3	 Maintenance... 49   
9.4	 Repair..... .49   
9.5	 Spare parts.. .49  

### 10 Decommissioning. 50  

#### 11	 Disassembly and replacement.. 50  

11.1 Required tools. 50   
11.2 Preparing disassembly. .50   
11.3 Disassembling the axial piston unit. .50   
11.4	Preparing the components for storage or further use. .51  

### 12 Disposal. 52  

12.1	Environmental protection. 52  

### 13	 Extension and conversion. 52  

### 14	 Troubleshooting. 53  

14.1 How to proceed for troubleshooting. 53   
14.2 Malfunction table. 54  

### 15 Technical data. 56  

### 16	 Appendix. ..56  

16.1 Address directory. 56  

### 17	 Index.  

#### About this document  

These instructions contain important information on the safe and appropriate assembly, transport, commissioning, maintenance, disassembly and simple troubleshooting of the A4VSO series 1, 2 and 3 axial piston variable pump.  

f Read these instructions completely, especially chapter "2 General safety instructions" on page 6, before working with the A4VSO axial piston variable pump.  

#### 1.1 Related documents  

The A4VSO axial piston variable pump is a system component. Also observe the instructions for the other system components.  

Further information on the A4VSO axial piston variable pump, its installation and operation can be found in the Rexroth documents listed in the following table.  

Table 1: Related documents   


<html><body><table><tr><td>Related documents</td><td>Contents</td></tr><tr><td>Orderconfirmation</td><td>ContainsthepresettechnicaldataofyourA4VSO axial piston variable pump.</td></tr><tr><td>Installationdrawing</td><td>Containstheouterdimensions,allconnections andthehydrauliccircuitdiagramforyourA4VSO axial piston variable pump.</td></tr><tr><td>DatasheetRE92050</td><td>Containsthepermissibletechnicaldataforthe Depending on the control unit of your axial piston pump, the followingsevendata sheets apply:</td></tr><tr><td>DatasheetRE92056</td><td>Speed control DS1,secondary control</td></tr><tr><td>DatasheetRE92060</td><td>ControldevicesDR,DP,FRandDFR</td></tr><tr><td>DatasheetRE92064</td><td>Power control LR2,LR3,LR2N and LR3N</td></tr><tr><td>DatasheetRE92072</td><td>ControlunitsMAandEM</td></tr><tr><td>DatasheetRE92076</td><td>Control systems HM, HS, HS4 and EO</td></tr><tr><td>DatasheetRE92080</td><td>Hydraulic control,pilot pressure related HD</td></tr><tr><td>DatasheetRE92088</td><td>Electro-hydraulic control system DFE1</td></tr><tr><td>DatasheetRE92053</td><td>Contains thepermissibletechnical datafor theA4VSO axialpistonvariablepumpwithHFChydraulicfluids.</td></tr><tr><td>DatasheetRE90220</td><td>Describes therequirements on a mineral-oil based hydraulic fluidforoperationwithRexroth axial piston units and assists you in selecting a hydraulic fluid for your system.</td></tr><tr><td>DatasheetRE90221</td><td>Describestherequirementsonanenvironmentallyacceptable hydraulicfluid for operation withRexroth axial piston units and</td></tr><tr><td>DatasheetRE90223</td><td>ContainsadditionalinformationontheuseofRexrothaxial piston units with HF hydraulic fluids.</td></tr><tr><td>Data sheet RE90300-03-B</td><td>ContainsadditionalinformationontheuseofRexrothaxial piston units at low temperatures.</td></tr></table></body></html>  

Also observe the generally applicable, legal or otherwise binding regulations of the European and national legislation and the rules for the prevention of accidents and for environmental protection applicable in your country.  

#### 1.2 Abbreviations used  

As umbrella term for "A4VSO axial piston variable pump", the designation "axial piston unit" will be used in the following.  

Table 2: Abbreviations   


<html><body><table><tr><td>Abbreviation</td><td>Meaning</td></tr><tr><td>A4VSO</td><td>Axial piston variable pump,open circuits</td></tr><tr><td>DR</td><td>Pressure control</td></tr><tr><td>DP</td><td>Pressure control for parallel operation</td></tr><tr><td>FR</td><td>Flow control</td></tr><tr><td>DFR</td><td>Pressure and flow control</td></tr><tr><td>LR2</td><td>Power control with hyperbolic characteristic</td></tr><tr><td>LR3</td><td>Power control with remotely controllable power characteristic</td></tr><tr><td>LR2N/LR3N</td><td>Hydraulic control, pilot pressure related, basic setting Vg min</td></tr><tr><td>MA</td><td>Manual control</td></tr><tr><td>EM</td><td>Electric motorized control</td></tr><tr><td>HD</td><td>Hydraulic control, pilot pressure related</td></tr><tr><td>HM1/2</td><td>Hydraulic control, volume related</td></tr><tr><td>HS, HS4</td><td>Control system with servo or proportional valve</td></tr><tr><td>EO1/2</td><td>Control system with proportional valve</td></tr><tr><td>DS1</td><td>Speed control, secondary control</td></tr><tr><td>DFE1</td><td>Electro-hydraulic control system</td></tr><tr><td>RE</td><td>Rexroth document in the English language</td></tr></table></body></html>  

#### 2	 General safety instructions  

The axial piston unit has been manufactured according to the generally accepted rules of current technology. There is, however, still a danger of personal injury or damage to equipment if the following general safety instructions and the warnings before the steps contained in these instructions are not complied with.  

ff Read these instructions completely and thoroughly before working with the axial piston unit.   
$\blacktriangleright$ f Keep these instructions in a location where they are accessible to all users at all times.   
f f Always include the operating instructions when you pass the axial piston unit on to third parties.  

#### 2.1 Intended use  

Axial piston units are components in terms of the EU machine directive 98/37/EC (sub units). Axial piston units are not ready-to-use machines for the purpose of the EU machine directive. The product/component is exclusively intended for being integrated in a machine or system or for being assembled with other components to form a machine or system. The product may only be commissioned after it has been installed in the machine/system for which it is intended.  

The axial piston variable pump generates, controls and regulates a hydraulicfluid flow. It is approved for use as a hydraulic pump in hydrostatic drives in open circuits.  

ff Observe the technical data, operating conditions and performance limits as specified in the data sheet and order confirmation.  

The axial piston unit is not designed for private use.   
Intended use includes having read and understood these instructions, especially chapter "2 General safety instructions".  

#### 2.2 Improper use  

The axial piston unit may not be used in explosive environments. In addition, any use of the axial piston unit other than described in chapter "2.1 Intended use" is considered to be improper.  

#### 2.3	 Personnel qualifications  

Assembly, commissioning and operation, disassembly, maintenance and repair require basic mechanical, hydraulic and electrical knowledge, as well as knowledge of the appropriate technical terms. For transporting and handling the product, additional knowledge is necessary with regard to working with a crane and the corresponding attachment equipment. In order to ensure operating safety, these activities may therefore only be carried out by qualified personnel or an instructed person under the direction and supervision of qualified personnel.  

Qualified personnel are those who can recognize possible hazards and institute the appropriate safety measures due to their professional training, knowledge, and experience, as well as their understanding of the relevant conditions pertaining to the work to be done. Qualified personnel must observe the rules relevant to the subject area.  

#### 2.4	 Safety instructions in this document  

In this manual, there are safety instructions before the steps whenever there is a danger of personal injury or damage to equipment. The measures described to avoid these hazards must be observed.  

Safety instructions are set out as follows:  

<html><body><table><tr><td>SIGNALWORD!</td><td>Type of danger!</td></tr><tr><td></td><td>Consequences</td></tr><tr><td></td><td>Precautions</td></tr></table></body></html>  

•• Safety sign: (warning triangle): draws attention to the danger •• Signal word: identifies the degree of the danger •• Type of danger: identifies the type or source of the dange •• Consequences: describes what occurs if the safety instructions are not complied with •• Precautions: states how the danger can be avoided.  

The signal words have the following meaning:  

<html><body><table><tr><td>Signal word!</td><td>Application</td></tr><tr><td>DANGER!</td><td>Indicates animminently hazardous situation which, if not avoided,will certainlyresult indeath orseriousinjury.</td></tr><tr><td>WARNING!</td><td>Indicatesapotentiallyhazardoussituationwhich,ifnot avoided,couldresult indeathorserious injury.</td></tr><tr><td>CAUTION!</td><td>Indicates a potentially hazardous situation which, if not avoided,couldresultinminorormoderateinjuryordamageto equipment.</td></tr><tr><td>1</td><td>If this information is disregarded,the operatingproceduremay be impaired.</td></tr></table></body></html>  

#### 2.5	 Adhere to the following instructions  

#### General instructions  

· Observe the regulations for accident prevention and environmental protection for the country where the product is used and at the workplace.  

•• Only use Rexroth axial piston units in good technical order and condition. –– Inspect the product for obvious defects.   
•• Do not modify or retrofit the axial piston unit.   
• Only use the product within the performance range provided in the technical data.   
•• Persons who assemble, commission, operate, disassemble or maintain Rexroth products must not consume any alcohol, drugs or pharmaceuticals that may affect their ability to respond.   
· The warranty only applies to the delivered configuration.   
•• The warranty is rendered void if the product is incorrectly assembled, commissioned or operated, as well as if not used as intended and/or handled improperly.   
•• Do not expose the product to any mechanical loads under any circumstances. Never use the product as a handle or step. Do not place/lay any objects on it.  

<html><body><table><tr><td></td><td>·Thenoiseemission of axialpistonunitsdepends onspeed,operatingpressure during normal operating conditions. This can cause hearing damage.</td></tr><tr><td>axial piston unit.</td><td>-Always wear hearing protection while working in the vicinity of the operating · The axial piston unit heats up considerably during operation. The solenoids of</td></tr><tr><td></td><td>- Allow the axial piston unit to cool down sufficiently before touching it. - Wear heat-resistant protective clothing, e.g. gloves.</td></tr><tr><td></td><td>During transport · Make certain that the lifting gear has adequate lifting capacity. The weight can s  su   n </td></tr><tr><td>During assembly</td><td>I·Before assembling,make sure that all fluids havebeen completely removed from the axial piston unit to prevent mixing with the hydraulic fluid used in the</td></tr><tr><td></td><td>system. · Make sure the relevant system component is not under pressure or voltage</td></tr><tr><td></td><td>Protect the system against being switched on. ao dun uo auo ou pue pabewp aq louueo rau peu os saul pue salqo Ke ·</td></tr><tr><td>product.</td><td>them. · Before commissioning, make sure that all hydraulic connections are tight and that all the connection seals and plugs are installed correctly to ensure that they</td></tr><tr><td></td><td>are leakproof and fluids and contaminants are prevented from penetrating the</td></tr><tr><td></td><td>· When assembling, provide for absolute cleanliness in order to prevent hydraulic lines and causing product wear or malfunctions.</td></tr><tr><td></td><td>During commissioning  · Ensure that all electrical and hydraulic connections and ports are occupied or plugged. Only commission a completely installed product.</td></tr><tr><td>During cleaning</td><td>detergents from penetrating the system.</td></tr><tr><td></td><td>· Never use solvents or aggressive detergents. Use only water and, if necessary, a mild detergent to clean the axial piston unit.</td></tr><tr><td></td><td>· Do not point the high-pressure cleaner at sensitive components such as, e.g. shaft seal ring, electrical connections and electrical components.</td></tr><tr><td></td><td>ng maintenance and repair  · Perform the prescribed maintenance work at the intervals specified in the</td></tr><tr><td></td><td>· Make sure that no lines, connections or components are disconnected as long</td></tr></table></body></html>  

#### 2.6	 Operator's obligations  

The operator of the axial piston unit from Rexroth must provide personnel training on a regular basis regarding the following subjects:  

•• Observation and use of the operating instructions and the legal regulations   
•• Intended use and operation of the axial piston unit   
•• Observation of the instructions from the factory security offices and of the work instructions from the operator Rexroth offers training support for special fields. You can find an overview of the training contents on the Internet at:   
http://www.boschrexroth.de/didactic.  

#### 3 Delivery contents  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/73440c2da07f496f94c51487bc60033f5ac7459cd7095994f1bcbee03ffa124e.jpg  
Fig. 1: Axial piston unit  

Included in the delivery contents are:  

•• 1 Axial piston unit  

The following parts are also assembled on delivery:  

•• Transport protection for drive shaft end (1).   
•• Protective covers (2).   
•• Plastic plugs / locking screws (3).   
•• Flange cover and fixing screws (4) (optional for versions with through drive).  

#### 4	 Product description  

#### 4.1	 Performance description  

The axial piston unit is designed and built for the generation, the control and the regulation of a hydraulic fluid flow. It is designed for stationary or mobile applications.  

Please refer to the data sheet and order confirmation for the technical data, operating conditions and operating limits of the axial piston unit.  

#### 4.2	 Device description  

The A4VSO is an axial piston variable pump with swashplate design for hydrostatic drives in open circuits. Flow is proportional to drive speed and displacement. The flow can be steplessly changed by controlling the swashplate.  

#### Open circuit  

With an open circuit, the hydraulic fluid flows from the tank to the variable pump and is transported from there to the consumer via a directional valve. From the consumer, the hydraulic fluid flows back to the tank via the directional valve.  

#### 4.2.1	 Assembly of the axial piston unit  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/72f2f7d1cd8ad3651b3ebf7fd67b9a8e031301390c7b96835aeb231e08c79265.jpg  
Fig. 2: Assembly of the A4VSO series 1, 2 and 3  

1 Drive shaft 5 High-pressure side 10	 Cylinder 2 Retaining plate 6 Control plate 11	 Piston 3 Stroke piston 7 Port plate 12	 Slipper pad 4 Control unit 8 Suction port 13 Swashplate (here using the DR 9 Low-pressure side as an example)  

For axial piston units with swashplate design, the pistons (11) are arranged axially with respect to the drive shaft (1). They are guided in the rotating cylinder (10) and support themselves with the slipper pads (12) on the non-rotating swashplate (13). The drive shaft (1) and cylinder (10) are connected to one another by means of gearing.  

#### 4.2.2	 Functional description  

#### Pump  

Torque is applied to the drive shaft (1) by an engine. The cylinder (10) turns with the drive shaft (1), turning with it the pistons (11). On each rotation, the pistons (11) perform a stroke movement which is defined by the pitch of the swashplate (13). The slipper pads (12) are held on and guided along the glide surface of the swashplate (13) by the retaining plate (2). During a rotation, each piston (11) moves over the bottom and top dead centers back to its initial position. During this action, the fluid volume defined by the piston surface and the stroke is fed in or removed through the two control slits in the control plate (6). On the low-pressure side (9), fluid flows into the enlarging piston chamber via the suction port (8). At the same time, on the high-pressure side (5) the fluid is pushed out of the cylinder chamber into the hydraulic system by the pistons.  

#### Control  

The swivel angle of the swashplate (13) is infinitely variable. By changing the swivel angle, the piston stroke and, therefore, the displacement change. The swivel angle is controlled hydraulically via the stroke piston (3). The swashplate (13) is mounted for easy motion in swivel bearings. Increasing the swivel angle increases the displacement; reducing the angle results in a corresponding reduction in displacement.  

The swivel angle can never be swiveled completely to zero because a minimum amount of hydraulic fluid is necessary for  

•• cooling the pistons,   
•• supplying the control,   
•• compensating for case drain fluid and •• lubricating all moving parts.  

#### 4.2.3	 Control devices  

DR Pressure control  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/f6232dbf4c551d2cc64957b54c580abb8218888ab140b523af3ffc3e2cdce039.jpg  

The DR pressure control serves to maintain a constant pressure in a hydraulic system within the control range of the pump. The pressure can be steplessly set on the control valve (setting range 20 to 350 bar).  

For further information, see data sheet RE 92060. Optional: with remote-controllable pressure control (DRG)  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/090d98aaab3e2fc3ec2555ee65581a94181dcdc9d29a65fc4ac628ed9dc79a31.jpg  
Fig. 3: Circuit diagram of A4VSO with DR pressure control  

DP Pressure control for parallel operation  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/7fbbde74f6871711b40a6b135a0b932a646424246d2ff7fc451faa645bc73328.jpg  

Suitable for pressure control of multiple A4VSO axial piston units in parallel operation.  

For further information, see data sheet RE 92060. Optional:   
Flow control (DPF)  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/e6691d6895800543fc843e9ae6928b191b540f8b62695cc828ffacf2024c352d.jpg  
1) Not included in the delivery contents Fig. 4: Circuit diagram of A4VSO with DP pressure control for parallel operation  

FR Flow control  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/f5687377f4ccdd458e42c1ac2fa487c712bedd93c9b3d1638a4e20ceddcb3051.jpg  

Maintaining a constant flow in a hydraulic system. For further information, see data sheet RE 92060. Optional: With remote-controllable pressure control (FRG), no connection from ${\sf X}_{\sf F}$ to the tank (FR1, FRG1)  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/60a5aab0e4c6020153f7b68017ddbee4cbd40feb08696275d7197472eea1994d.jpg  
1) Not included in the delivery contents Fig. 5: Circuit diagram of A4VSO with FR flow control  

#### DFR Pressure and flow control  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/807cba7ec47070439b39e29ecfa258befdf736220b9289c7be3be64b300050f6.jpg  

This controller keeps the flow of the pump constant even under changing operating conditions. A mechanically adjustable pressure controller overrides the flow control.  

For further information, see data sheet RE 92060. Optional: No connection from $\mathsf{X}_{\mathsf{F}}$ to the tank (DFR1)  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/46a53e33c9a316c90727586c135509f5c664d479742a5e9c02b9c36871d94c8b.jpg  
1) Not included in the delivery contents Fig. 6: Circuit diagram of A4VSO with DFR pressure and flow control  

LR2 Power control with hyperbolic characteristic  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/980d5c68bed719080248da6eeb4aac16d552465f686c4c2d277db490022dc205.jpg  

The hyperbolic power control keeps the specified drive power constant at the same drive speed.  

For further information, see data sheet RE 92064.  

Optional:  

With pressure control (LR2D), remote-controllable pressure control (LR2G);   
with flow control (LR2F, LR2S);   
with hydraulic stroke limiter (LR2H);   
with mechanical stroke limiter (LR2M);   
with hydraulic two-point control (LR2Z);   
with electric relief valve as start assistance (LR2Y).  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/a9b975e108f73091b0d5719b9bc516e3131f0c3f3db4ef2df941fe10a5379bba.jpg  
Fig. 7: Circuit diagram of A4VSO with LR2 power control  

LR3 Power control with remotecontrollable power characteristic  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/9537e2af84c2bb28692c916014e7622fedb539b5979c835bf8a9c29b92f62b95.jpg  

This hyperbolic power control keeps the specified drive power constant, whereby the power characteristic can be controlled remotely.  

For further information, see data sheet RE 92064.  

Optional: With pressure control (LR3D), remote-controllable pressure control (LR3G);   
with flow control (LR23, LR3S);   
with hydraulic stroke limiter (LR3H);   
with mechanical stroke limiter (LR3M);   
with hydraulic two-point control (LR3Z);   
with electric relief valve as start assistance (LR3Y).  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/8781fb533636f67501d0d6bd53ab754314e5edab3fe861aa172a946e279f2895.jpg  
Fig. 8: Circuit diagram of A4VSO with LR3 power control  

LR2N and LR3N Hydraulic control, pilot pressure related, basic setting $\mathsf{\pmb{V}}_{\mathfrak{g}\operatorname{min}}$  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/6e8e7bb869012dae4eaa0c251e019fb5b1e8671b4ae488c1e41394eb44f9d307.jpg  

With overriding power control.  

The displacement is increased in proportion to the pilot pressure in $\mathsf{P}_{\mathsf{S t}}$ . The additional hyperbolic power control overrides the pilot pressure signal and keeps the specified drive power constant.  

For further information, see data sheet RE 92064.  

Optional:   
remote controllable power characteristic (LR3N)   
with pressure control (LR.DN), remote controllable pressure control (LR.GN); with electric pilot pressure specification (LR.NT)  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/4052b8ad62d92f7cf3c37cd71e08ce720a59f26264115430861f683d4b8f4b82.jpg  
1) Shown in switched position, i.e. P pressurized Fig. 9: Circuit diagram of A4VSO with LR2N hydraulic control  

#### MA Manual control  

The displacement is steplessly adjustable via a handwheel.   
For further information, see data sheet RE 92072.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/ff081114590c6785d215c5b8a96d9eb90e8eb6607220cc2fbf71aa9e834e1bb9.jpg  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/c0a0c9f68fc1f2e4bb800ad4bf14b9496cbb9eeadd98837e70b83d11497e1f4a.jpg  
Fig. 10: Circuit diagram of A4VSO with MA manual control  

#### EM Electric motorized control  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/0306d49bc1d2af1da4264354ceeae37037bd5b408e2a66c804a13e40155a95ee.jpg  

The displacement is steplessly controlled via an electric variable motor. With a programmed sequence control, various intermediate displacements can be selected by means of built-on limit switches or a potentiometer for swivel-angle feedback.  

For further information, see data sheet RE 92072.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/5d90b6090173c89376481c54200d0e59271eaf4470bee8dadd6ffaba43f7be65.jpg  
Fig. 11: Circuit diagram of A4VSO with EM electric motorized control  

HD Hydraulic control, pilot pressure related  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/f51c17dad13ca296cad1c1c17bd5fb99b7801ca226d80a92db8c6abb2cff460b.jpg  

Stepless adjustment of the pump displacement according to the pilot pressure.   
The control is proportional to the specified pilot pressure setpoint. For further information, see data sheet RE 92080.   
Optional:   
Control characteristics (HD1, HD2, HD3)   
with pressure control (HD.B), remote controllable pressure control (HD.GB) with power control (HD1P)   
with electric pilot pressure specification (HD1T)  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/26aa6b1b291624633cebaab5564e80c080448c8d49004a0004ef7f052c1ef05e.jpg  
Fig. 12: Circuit diagram of A4VSO with HD hydraulic control  

#### HM1/2 Hydraulic control, volume related  

The pump displacement is steplessly adjustable depending on the flow of pilot fluid in ports ${\sf X}_{1}$ and ${\sf X}_{2}$ .  

For further information, see data sheet RE 92076.  

Application:  

•• 2-point switching •• Base device for servo or proportional controls  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/230baf2558847b61c1f1756b83aab68a3956bed1fa2c90a63e9abd5c20956d75.jpg  
Fig. 13: Circuit diagram of A4VSO with HM1/2 hydraulic control  

HS, HS4 Control system with servo or proportional valve  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/f1c33a85847a51de69fe7752b68fd297142ef97b9ffc4463d1b110d35194755b.jpg  

The displacement is steplessly controlled via a servo or proportional valve and electric swivel-angle feedback.  

Electrically or electronically controllable.  

For further information, see data sheet RE 92076.  

Optional:   
With servo valve (HS);   
with proportional valve (HS4);   
with short-circuit valve (HSK, HS4K, HS4KP); without valves (HSE, HS4E);   
suitable for tank installation (HS4M)  

The HS4P control system is equipped with mounted pressure transducer, which means that it can be used for electric pressure and power control.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/fad06a4f34a2fe07ef1531fcdf73a8088254d5992bae8b8f138c8046a2363b14.jpg  
Fig. 14: Circuit diagram of A4VSO with HS, HS4 control system  

#### Control system EO1/2  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/c1cbe11815bdbd93a7a8778975f5e12981ac7b377a0443e3241552ab58846746.jpg  

The displacement is steplessly controlled via a servo or proportional valve and electric swivel-angle feedback.  

Electrically controllable.   
For further information, see data sheet RE 92076. Optional:   
With short-circuit valve (EO1K, EO2K)   
without valves (EO1E, EO2E)  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/87a3fc2a5a49f98f4898006661d2df29943e3cb97a728c1526a196a98927596f.jpg  
Fig. 15: Circuit diagram of A4VSO with EO1/2 control system  

DS1 Speed control, secondary control  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/6df9bcaf51371f3373416df6e2a11a876a3913fcbec0a9e8132f5da675b549f2.jpg  

The DS1 speed control controls the secondary unit in such a way that the necessary torque is available for the required speed. When connected to a constant pressure system, this torque is proportional to the displacement and thus also proportional to the swivel angle.  

For further information, see data sheet RE 92056.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/84bc8948b49313099bcc4d1f28b63dc3f37c06810f3fb3f88ecf193984e407f1.jpg  
Fig. 16: Circuit diagram of A4VSO with DS1 speed control  

DFE1 Electro-hydraulic control system  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/831229d159d88cd99672bce1596b7e0717dd0b694be02c8d918f5be034775d7b.jpg  

The power, pressure and swivel angle control of the A4VSO...DFE1 variable pump is performed by means of an electrically controllable proportional valve. The flow at the proportional valve determines the position of the swashplate – and thus the pump flow – via the stroke piston and the displacement pick-up. When the electric engine is switched off and the actuator system is depressurized, the pump swivels to maximum displacement by means of spring force $(\mathsf{V}_{\mathsf{g}\mathsf{m a x}})$ . For further information, see data sheet RE 92088.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/4c6d6f0a99b23b9d9083874d4eebb54ddfdb25ce277ca2170eec7b8c2725f8c3.jpg  
1) Delivery contents Fig. 17: Circuit diagram of A4VSO with DFE1 electro-hydraulic control system  

#### 4.3 Product identification  

The axial piston unit can be identified with the name plate. The following example shows an A4VSO name plate:  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/bd47eb3742c4fb06d8bef8bc7d9e02b7aeab15e52b25085bc4c7c7fb4a932cca.jpg  
Fig. 18: A4VSO name plate  

1 Manufacturer   
2 Production date   
3 Internal plant designation   
4 Direction of rotation (looking at   
drive shaft) – here: clockwise   
5 Power setting (optional)   
6 Barcode   
7 Rotational speed   
8 Flow setting (optional)   
9 Pressure control setting (optional)   
10	 Displacement   
11	 Serial number   
12	 Material number of the   
axial piston unit   
13	 Ordering code   
14	 Customer number  

#### 5 Transport and storage  

#### 5.1	 Transporting the axial piston unit  

CAUTION!  

#### Risk of damage!  

Hitting or impulsive forces on the drive shaft can damage the axial piston unit.  

$\blacktriangleright$ Do not hit the coupling or drive shaft of the axial piston unit. $\blacktriangleright$ Do not set/place the axial piston unit on the drive shaft. $\blacktriangleright$ Details on the permissible axial and radial forces can be found in the data sheet.  

Axial piston units can be transported with a fork lift truck or with a lifting device.  

Make certain that the fork lift truck or lifting device has adequate lifting capacity.  

#### Dimensions and weights  

Table 3: Dimensions and weights   


<html><body><table><tr><td>Size</td><td>40</td><td>71</td><td>125</td><td>180</td><td>250</td><td>355</td><td>500</td><td>750</td><td>7501)</td><td>1000</td></tr><tr><td>Weight</td><td>kg 39</td><td>53</td><td>88</td><td>102</td><td>184</td><td>207</td><td>320</td><td>460</td><td>490</td><td>605</td></tr><tr><td>Width</td><td>mm</td><td rowspan="3">The dimensions vary with the unit type.The values applicable toyour axial piston unit can be found in the installation drawing.</td><td rowspan="3"></td><td rowspan="3"></td><td rowspan="3"></td><td rowspan="3"></td><td rowspan="3"></td><td rowspan="3"></td><td rowspan="3"></td></tr><tr><td>Height</td><td>mm</td></tr><tr><td>Depth</td><td>mm</td></tr></table></body></html>

1) With charge pump  

#### 5.1.1	 Transporting with lifting device  

For transporting, the axial piston unit can be connected to a lifting device via a ring screw or a lifting strap.  

#### Transport with ring screw  

The drive shaft can be used to transport the axial piston unit as long as only outward axial forces occur. Thus, you can suspend the axial piston unit from the drive shaft.  

$\blacktriangleright$ To do this, screw a ring screw completely into the thread on the drive shaft. The size of the thread is stated in the installation drawing.   
$\blacktriangleright$ Make sure that each ring screw can bear the total weight of the axial piston unit plus approx. $20\%$ .  

You can hoist the axial piston unit as shown in Fig. 19 using the ring screw screwed into the drive shaft without any risk of damage.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/696deb00294d8936a62d0fb933f752fe5351fc6b9f037b2009f94d2152833a4a.jpg  
Fig. 19: Fixing the ring screw  

#### Transport with lifting strap  

Place the lifting strap around the axial piston unit in such a way that it passes over neither the attachment parts (e.g. valves) nor such that the axial piston unit is hung from attachment parts (see Fig. 20).  

WARNING!  

#### Risk of injury!  

During transport with a lifting device, the axial piston unit can fall out of the lifting strap and cause injuries.  

Hold the axial piston unit with your hands to prevent it from falling out of the lifting strap.   
Use the widest possible lifting strap.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/eac09ba6b1058d8f3a7035578b028becc391ed10d00645439f08f0bde17a6b78.jpg  
Fig. 20: Transport with lifting strap  

#### 5.2	 Storing the axial piston unit  

#### Requirement  

· The storage areas must be free from corrosive materials and gasses.   
•• The storage areas must be dry.   
•• The ideal temperature for storage lies between $\mathtt{+5}^{\circ}\mathtt{C}$ and $+20~^{\circ}\mathrm{C}$ .   
•• Avoid intense lights.   
•• Do not stack axial piston units and store them shock-proof.   
•• For other storage conditions, see Table 4.  

$\blacktriangleright$ f Check the axial piston unit monthly to ensure proper storage.  

#### After delivery  

The axial piston unit is provided ex-works with a corrosion protection packaging (corrosion protection film).  

Listed in the following table are the maximum permissible storage times for an originally packed axial piston unit.  

Table 4: Storage time with factory corrosion protection   


<html><body><table><tr><td>Storageconditions</td><td>Standardcorrosion protection</td><td>Long-term corrosionprotection</td></tr><tr><td>Closed, dry room, uniform temperaturebetween+5°C and+20°C.Undamaged andclosedcorrosion protectionfilm.</td><td>Maximum12months</td><td>Maximum24months</td></tr></table></body></html>  

The warranty is rendered void if the requirements and storage conditions are not adhered to or after expiration of the maximum storage time (see Table 4).  

Procedure after expiration of the maximum storage time:  

1.	 Check the entire axial piston unit for damage and corrosion prior to installation. 2.	 Check the axial piston unit for proper function and leaks during a test run. 3.	 Replace the shaft seal ring if the storage time of 24 months is exceeded.  

After expiration of the maximum storage time, we recommend that you have the axial piston unit inspected by your responsible Rexroth Service partner.  

In the event of questions regarding spare parts, contact your responsible Rexroth Service partner or the service department of the manufacture's plant for the axial piston unit, see chapter "9.5 Spare parts" for further information.  

#### After disassembly  

If a dismounted axial piston unit is to be stored, it must be conserved against corrosion for the duration of the storage.  

The following instructions only refer to axial piston units which are operated with a mineral-oil based hydraulic fluid. Other hydraulic fluids require conservation methods that are specifically designed for them. In such a case consult with Rexroth Service (see chapter $"9.5$ Spare parts" for address).  

Rexroth recommends the following procedure:  

1.	 Clean the axial piston unit, see chapter $"9.1$ Cleaning and care" for further information.   
2.	 Completely empty the axial piston unit.   
3.	 For storage time up to 12 months: Moisten the inside of the axial piston unit with mineral oil and fill with approx. $100~\mathsf{m}$ mineral oil. For storage time up to 24 months: Fill the axial piston unit with corrosion protection VCI 329 $(20~\mathsf{m}|)$ ). Fill via case drain port $\mathsf{K}_{1}$ or $K_{2}$ , see chapter $"6.4$ Assembling the axial piston unit", Fig. 28.   
4.	 Seal all ports airproof.   
5.	 Moisten the unpainted surfaces of the axial piston unit with mineral oil.   
6.	 Package the axial piston unit airproof together with desiccant in corrosion protection film.   
$7.$ Store the axial piston unit so that it is protected against jolts. See "Requirement" in this chapter for further conditions.  

#### 6 Assembly  

Prior to assembly, the following documents must be available:  

•• Installation drawing for the axial piston unit (available from Rexroth) •• Hydraulic circuit diagram for the axial piston unit (in the installation drawing) •• Hydraulic circuit diagram for the system (available from the system manufacturer) •• Order confirmation (contains the preset data of the axial piston unit) •• Data sheet for the axial piston unit (contains the technical data)  

#### 6.1 Unpacking  

The axial piston unit is delivered in a corrosion protection film made of polyethylene material.  

f Dispose of the packaging according to the national regulations of your country.  

CAUTION!  

#### Risk of parts falling out  

If the packaging is not opened correctly, parts may fall out and damage the parts or even result in injury.  

ff Place the packaging on a flat and solid surface.   
ff Only open the packaging from the top.  

#### 6.2	 Installation conditions  

•• The installation location and position of the axial piston unit essentially determine the procedures during installation and commissioning (such as when filling the axial piston unit).  

•• Note that you can expect certain installation positions to affect the control device. Because of gravity, dead weight and case pressure, minor characteristic displacements and actuating time changes may occur.  

Adhere to all limits specified in the data sheet regarding temperature, viscosity, cleanliness of the hydraulic fluid. Make certain that the case of the axial piston unit is filled with hydraulic fluid during commissioning and operation. This is also to be observed following relatively long standstill periods as the axial piston unit may empty via the hydraulic lines.   
ff The case drain fluid in the case interior must be directed to the tank via the highest case drain port. Use the line size which is appropriate for the port.   
ff A check valve in the case drain line is only permissible on a case-by-case basis upon request.   
ff To achieve favorable noise values, decouple all connecting lines from all vibration-capable components (e.g. tank) using elastic elements.   
f Make certain that the suction line, case drain line, and return line flow into the tank below the minimum fluid level in all operational states.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/f207d2a455791aadc66351447a51030b2d9a687a367c3869f449053c3305e99e.jpg  
Fig. 21: Suction pressure  

1	 Absolute pressure gauge   
2 Standard pressure gauge  

ff Make certain that a minimum suction pressure of 0.8 bar absolute is present at port "S" during operation and on cold starts in all installation positions and installation locations for the axial piston pump, see Fig. 21. See data sheet for additional values.  

f Absolute cleanliness is required. The axial piston unit must be installed in a clean condition. Contamination of the hydraulic fluid can have a considerable impact on the service life of the axial piston unit.  

$\blacktriangleright$ Do not use any cotton waste or linty cloths for cleaning.  

$\blacktriangleright$ f Use suitable liquid detergents to remove lubricants and other difficult-toremove contamination. Detergents must not penetrate the hydraulic system.  

Caution! △  

#### Risk of damage by air inclusions!  

An air pocket in the area near the bearings will damage the axial piston unit.  

$\blacktriangleright$ Make certain that the pump case is completely filled with hydraulic fluid during commissioning and during operation with the "drive shaft upwards" installation position. During commissioning and during operation, the suction line must be filled with hydraulic fluid.  

Caution! △  

#### Risk of damage by hydraulic fluid loss!  

With above-tank installation, the case interior may drain via the case drain line after longer standstill periods (air enters via the shaft seal ring) or via the service line (gap leakage). The bearings are thus insufficiently lubricated when the pump is restarted.  

Check the hydraulic fluid level in the case interior regularly; if necessary, recommission.  

#### 6.3 Installation position  

The following installation positions are permissible. The shown piping layout illustrates the basic layout.  

#### 6.3.1	 Below-tank installation  

Below-tank installation is when the axial piston unit is installed outside of the tank below the minimum hydraulic fluid level.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/78ea5dc634644387483b8f998ded574600b9f1aef469dc0ee85a4fb157b2e59b.jpg  
Fig. 22: Below-tank installation with horizontal installation position 1 and vertical installation position 2  

<html><body><table><tr><td>F</td><td>Filling / airbleeding</td><td>U</td><td>Flowport</td></tr><tr><td>R(L)</td><td>Fluid filling</td><td>SB</td><td>Baffle(baffleplate)</td></tr><tr><td>T</td><td>Fluiddrain</td><td>htmin</td><td>Min. permissible immersion depth</td></tr><tr><td>S</td><td>Suctionport</td><td>hmin</td><td>Min.permissibledistancefromsuction porttotankbase</td></tr></table></body></html>  

Table 5: Below-tank installation   


<html><body><table><tr><td>Installation position</td><td>Airbleeding Filling</td><td></td></tr><tr><td>1 (drive shaft, horizontal)</td><td>R(L) (F)</td><td>S +R(L) (F)</td></tr><tr><td>2 (drive shaft, vertical)</td><td>R(L) (F)</td><td>S+T</td></tr></table></body></html>  

#### 6.3.2	 Tank installation  

Tank installation is when the axial piston unit is installed in the tank below the minimum hydraulic fluid level. The axial piston unit is completely below the hydraulic fluid.  

Caution!  

#### Risk of damage during tank installation  

To prevent damages to the axial piston unit, all plastic parts (e.g. protective caps, covers) must be removed prior to installation in the tank.  

ff Remove all plastic parts before installing the axial piston unit in the tank. Make certain that no pieces of these parts remain in the tank. Axial piston units with electrical component must not be installed below the hydraulic fluid level.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/3efa786568de746d4bf715e388dacc6e243bcd66397ec6b2ecfb0929254eec54.jpg  
Fig. 23: Tank installation with horizontal and vertical installation position 3  

R(L) Air bleed port $\mathsf{K}_{1},\mathsf{K}_{2},$ U Flow port   
T Fluid port SB Baffle (baffle plate)   
S Suction port hmin Min. permissible distance from lower edge of suction port to tank base  

Table 6: Tank installation   


<html><body><table><tr><td>Installation position</td><td>Airbleeding</td><td>Filling</td></tr><tr><td>3</td><td>via the highest opened port T, K1, K2, R(L), U</td><td>via all opened ports T, K1, K2, R(L), U and S automatic, due to position below hydraulicfluidlevel</td></tr></table></body></html>  

#### 6.3.3	 Above-tank installation  

Above-tank installation is when the axial piston unit is installed above the minimum fluid level of the tank.  

For vertical installation (shaft end upward), Rexroth recommends the use of a bearing flushing at port "U" in order to ensure lubrication of the front bearing and of the shaft seal ring.  

Caution! △  

#### Risk of damage to the product!  

An air pocket in the area near the bearings will damage the axial piston unit.  

ff Make certain that the pump case is completely filled with hydraulic fluid during commissioning and during operation with the "drive shaft upwards" installation position.   
f Check the hydraulic fluid level in the case interior regularly; if necessary, recommission. With above-tank installation, the case interior may drain via the case drain line after longer standstill periods (air enters via the shaft seal ring) or via the service line (gap leakage). The bearings are thus insufficiently lubricated when the pump is restarted. Make certain that the suction line is always filled with hydraulic fluid during commissioning and operation.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/0ee573fc5de6c3670dc79ed50d3a53bca66dcd3d76f7ddd88a52306e1e57f8c1.jpg  
Fig. 24: Above-tank installation with horizontal installation position 4 and vertical installation position 5  

<html><body><table><tr><td>F</td><td>Filling/ airbleeding</td><td>SB</td><td>Baffle(baffleplate)</td></tr><tr><td>R(L)</td><td>Fluid filling</td><td>hs max</td><td>Max.permissiblesuctionheight</td></tr><tr><td>T</td><td>Fluiddrain</td><td>htmin</td><td>Min.permissibleimmersiondepth</td></tr><tr><td>S</td><td>Suctionport</td><td>hmin</td><td>Min.permissibledistancefrom suctionporttotankbase</td></tr><tr><td>U</td><td>Flowport</td><td></td><td></td></tr></table></body></html>  

Table 7: Above-tank installation   


<html><body><table><tr><td>Installation position</td><td>Airbleeding</td><td>Filling</td></tr><tr><td>4 (drive shaft, horizontal)</td><td>R(L) (F)</td><td>R(L) (F)</td></tr><tr><td>5 (drive shaft, vertical)</td><td>U (F)</td><td>T (F)</td></tr></table></body></html>  

#### 6.4	 Assembling the axial piston unit  

Danger! △  

#### Systems which are in operation pose a risk of injury!  

Working on operating systems poses a danger to life and limb. The work steps described in this chapter must only be performed on systems which are at a standstill. Before beginning work:  

$\blacktriangleright$ Ensure that the engine cannot be switched on.   
$\blacktriangleright$ f Ensure that all power-transmitting components and connections (electric, pneumatic, hydraulic) are switched off according to the manufacturer's instructions and are secured against being switched on again. If possible, remove the main fuse for the system. f Ensure that the system is completely hydraulically relieved and depressurized. Please follow the system manufacturer's instructions.   
$\blacktriangleright$ f Only qualified personnel (see chapter $^{"}2.3$ Personnel qualifications" on page 6) are authorized to assemble the axial piston unit.  

#### 6.4.1	 Preparation  

1.	 Check the delivery contents for completeness and transport damages.  

2.	 Compare the material number and designation (ordering code) with the details in the order confirmation.  

If the material number for the axial piston unit does not correspond to the one in the order confirmation, contact Rexroth Service for clarification, see chapter $"9.5$ Spare parts" for address.  

3.	 Before assembling, completely empty the axial piston unit to prevent mixing with the hydraulic fluid used in the system.  

4.	 Check the direction of rotation of the axial piston unit (on the name plate) and make sure that this corresponds to the direction of rotation of the engine.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/95904866e9c0e43584c996cc0384dd1171da2d1f2f28145acbc3731869c31288.jpg  
Fig. 25: Direction of rotation  

L Counter-clockwise R Clockwise  

The direction of rotation as specified on the name plate determines the direction of rotation of the axial piston unit as viewed on the drive shaft. For information on the direction of rotation of the engine, please refer to the engine manufacturer's operating instructions.  

5.	 Check the swivel angle indicator on the axial piston unit.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/594d1333505d5a209620c9f52e9e177f866a8a8946a1e36f3158ffa003c7b458.jpg  
Fig. 26: Swivel angle indicator  

Note that if the swivel angle indicator is not on $"0"$ , the axial piston unit will automatically transport hydraulic fluid on the initial commissioning.  

#### 6.4.2	 Dimensions  

The installation drawing contains the dimensions for all ports on the axial piston unit. Also observe the instructions provided by the manufacturers of the other components when selecting the required tools.  

#### 6.4.3	 General instructions  

During assembly (and disassembly) of the axial piston unit, observe the following general instructions and handling instructions:  

•• After a short operating time, toothed belts lose a major portion of their pre-tension and thus cause speed variations and torsional vibrations. Torsional vibrations may cause leakages on the shaft seal ring or increased rotary angle accelerations of the rotary group of the driven axial piston unit. Particularly at risk are diesel drives with a small number of cylinders and low flywheel mass.   
•• V-belt drives without automatic tensioning device are also critical with regard to speed variations and torsional vibrations. These can also lead to leakages on the shaft seal ring. An automatic tensioning device can lessen the speed variations and vibrations and thus avoid consequential damage.   
•• When driving an axial piston unit with the aid of a cardan shaft, vibrations may occur which may result in leakages on the shaft seal ring of the axial piston unit depending on the temperature and frequency.   
ff When driving with toothed belts or v-belts, always use an automatic tensioning device.   
ff Fix the axial piston unit so that the expected forces and torques can be transferred without any danger. The permissible axial and radial loading of the drive shaft, the permissible torsional vibration, the optimum direction of load force, as well as the limit speeds can be found in the data sheet. f Observe the permissible radial forces on the drive shaft when driving with radial loading (belt drives). If necessary, the belt pulley must be separately mounted.  

WARNING! △  

#### Risk of damage!  

Hitting or impulsive forces on the drive shaft can damage the axial piston unit.  

$\blacktriangleright$ Do not hit the coupling or drive shaft of the axial piston unit. $\blacktriangleright$ Do not set/place the axial piston unit on the drive shaft. $\blacktriangleright$ Details on the permissible axial and radial forces can be found in the data sheet.  

How to assemble the axial piston unit depends on the connecting elements to the drive side. The following descriptions explain the installation of the axial piston unit:  

•• with a coupling •• on a gearbox •• with cardan shaft  

#### 6.4.4	 Installation with coupling  

How to assemble the axial piston unit with a coupling is described in detail in the following:  

1.	 Assemble the specified coupling half onto the drive shaft of the axial piston unit according to the instructions of the coupling manufacturer.  

The drive shaft end of the axial piston unit is provided with a threaded bore.   
Use this threaded bore to pull the coupling element onto the drive shaft.   
Refer to the installation drawing for the dimensions of the threaded bore.  

2.	 Make sure that the installation location is clean and free from dirt and contaminants.  

3.	 Clamp the coupling hub onto the drive shaft or ensure permanent lubrication of the drive shaft. This prevents the formation of frictional corrosion and the associated wear.  

4.	 Transport the axial piston unit to the installation location.  

5.	 Assemble the coupling onto the drive according to the instructions of the coupling manufacturer.  

The axial piston unit must not be tightened down until the coupling has been correctly assembled.  

6.	 Fix the axial piston unit at the installation location.  

7.	 If necessary, details on the required tools and tightening torques for the fixing screws are available from the machine or system manufacturer.  

–– For bell housing installation, check the coupling axial play through the bell window according to the manufacturer's instructions.   
–– For flange installation, align the support for the axial piston unit with the drive.  

8.	 When using flexible couplings, check that the drive is free of resonance after completing the installation.  

#### 6.4.5	 Installation on a gearbox  

How to assemble the axial piston unit on a gearbox is described in detail in the following:  

After installing on a gearbox, the axial piston unit is covered and is difficult to access:  

ff Therefore, before installing, make sure that the centering diameter centers the axial piston unit (observe tolerances) and that no impermissible axial or radial forces act on the drive shaft of the axial piston unit (installation length).   
ff Protect the spline of the drive shaft from frictional corrosion by providing permanent lubrication.  

#### 6.4.6	 Installation with cardan shaft  

To connect the axial piston unit to the engine via a cardan shaft:  

1.	 Position the axial piston unit close to the specified installation point. It should allow enough space for the cardan shaft to fit through on both sides.   
2.	 Position the cardan shaft on the output shaft of the engine.   
3.	 Push the axial piston unit to the cardan shaft and position the cardan shaft on the drive shaft of the axial piston unit.   
4.	 Bring the axial piston unit to the installation position and secure. If necessary, details on the required tools and tightening torques for the fixing screws can be obtained from the system manufacturer.  

#### 6.4.7	 Completing assembly  

1.	 Remove any mounted transport screws.  

2.	 Remove the transport protection. The axial piston unit was delivered with protective covers and plastic plugs or locking screws. These must be removed before connecting. Use appropriate tools.  

3.	 Make certain that the sealing and functional surfaces are not damaged.  

Ports which are intended for connecting lines are provided with plastic plugs or locking screws which serve as transport protection. If no connection is made, these ports must be plugged with a suitable metal locking screw since the plastic plugs are not pressure-proof.  

Caution! △  

#### Risk of damage to persons and property!  

Operating the axial piston unit with plastic plugs can result in injuries or damage to the axial piston unit.  

f Before commissioning, remove all plastic plugs and replace them with suitable, pressure-proof, metal locking screws.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/043bddd5102cfab506ea078725c64e26cf15aaa3db15c7bc927a0df941e1452c.jpg  
Fig. 27: Removing transport protection  

1 Transport protection for shaft end   
2 Protective covers   
3 Plastic plugs / locking screws  

4 Flange cover and fixing screws (optional for versions with through drive)  

The adjusting screws are protected against unauthorized resetting by means of protective caps. Removal of the protective caps will void the warranty. If you need to modify the setting, please contact your responsible Rexroth Service (address as to chapter "9.5 Spare parts").  

4.	 For versions with through drive, assemble the auxiliary pump according to the pump manufacturer's instructions.  

#### 6.4.8	 Hydraulically connecting the axial piston unit  

The machine or system manufacturer is responsible for dimensioning the lines. The axial piston unit must be connected to the rest of the hydraulic system in accordance with the hydraulic circuit diagram of the machine or system manufacturer.  

Caution!  

#### Damage to the axial piston unit!  

When installing hydraulic lines and hoses under mechanical stress, they are exposed to additional mechanical forces during operation which reduce the service life of the axial piston unit and the entire machine or system.  

ff Assemble hydraulic lines and hoses without mechanical stress.  

Caution!  

#### Risk of damage!  

Generally, a minimum permissible suction pressure at port $"{\mathsf{S}}"$ is specified for axial piston pumps in all installation positions. If the pressure at port "S" drops below the specified values, damage may occur which may lead to destruction of the axial piston pump.  

Make certain that the necessary suction pressure is achieved. This is influenced by:   
– appropriate piping of the suction cross-section   
– appropriate pipe diameters   
– appropriate position of the tank   
– appropriate viscosity of the hydraulic fluid  

Only connect hydraulic lines to the service and function ports.  

CAUTION!  

#### Wear and malfunctions  

The cleanliness of the hydraulic fluid has a considerable impact on the cleanliness and service life of the hydraulic system. Any contamination of the hydraulic fluid leads to wear and malfunctions. In particular, contaminants like e.g. welding beads or metal cuttings in the hydraulic lines may damage the axial piston unit.  

ff Absolute cleanliness is required.   
ff The axial piston unit must be installed in a clean condition.   
f Make sure that all ports, hydraulic lines and add-on units (e.g. measuring devices) are clean.   
ff Make sure that no contaminants penetrate when sealing the ports.   
ff Make sure  that no detergents enter the hydraulic system.   
ff Do not use any cotton waste or linty cloths for cleaning.   
ff Do not use hemp as sealant under any circumstances.  

#### Notes on routing the lines  

Observe the following notes when routing the suction, pressure and case drain lines.  

$\blacktriangleright$ Make certain that the suction line (pipe or hose) is as short and straight as possible.   
$\blacktriangleright$ f The line cross section of the suction line is to be measured so that the minimum permissible pressure at the suction port is not dropped below and the maximum permissible pressure is not exceeded.   
$\blacktriangleright$ f Observe the air tightness of the junctions and the pressure resistance of the hose, also with respect to the external air pressure.   
$\blacktriangleright$ With the pressure lines, make certain that the pipes, hoses and connecting elements are approved for the operating pressure range.   
$\blacktriangleright$ f Always route the case drain lines so that the housing is constantly filled with hydraulic fluid and to ensure that no air gets through the shaft seal ring even during extended standstill periods. The case internal pressure must not exceed the limit values listed for the axial piston unit in the data sheet under any operating conditions. The case drain line in the tank must end up below the minimum fluid level under all conditions (see chapter "6.3 Installation position").  

The ports and fixing threads are designed for the operating pressures specified in the data sheet. The machine or system manufacturer must ensure that the connecting elements and lines correspond to the specified operating conditions (pressure, flow, hydraulic fluid, temperature) with the necessary safety factors.  

Procedure To connect the axial piston unit to the hydraulic system:  

1.	 Remove the locking screws at the ports at which the connections are to be made according to the hydraulic circuit diagram.   
2.	 Use only clean hydraulic lines.   
3.	 Connect the lines according to the hydraulic circuit diagram. Either pipes or hoses must be connected to all ports according to the installation drawing and machine or system circuit diagram or the ports plugged using suitable locking screws.  

The installation drawing contains the dimensions for all connections and ports on the axial piston unit. Also observe the instructions provided by the manufacturers of the other hydraulic components when selecting the required tools.  

4.	 Make sure  

–– that the cap nuts are correctly tightened on the fittings and flanges (observe tightening torques!). Mark all checked fittings using e.g. a permanent marker –– that the pipes and hose lines and every combination of connecting piece, coupling or connecting point with hoses or pipes have been inspected by a technically qualified person for safe working condition.  

Port overview  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/7f879a71a4410b6861ebef8e72b41f306756f455b5f2f32961779cb78fce6a21.jpg  

1) Version $\mathsf{M}_{\mathsf{B}}$ below: valid for sizes 40, 71, 125, 250 and 500   
2) Version $\mathsf{M}_{\mathsf{B}}$ rear: valid for sizes 180, 355, 750 and 1000  

Fig. 28: Port overview of A4VSO series 1, 2 and 3 (standard ports)   
Table 8: Ports of A4VSO series 1, 2 and 3   


<html><body><table><tr><td>Designation</td><td>Function</td><td>Control device (optional)</td><td>Standard</td><td>Peak pressure (bar) 1)</td><td>State</td></tr><tr><td>B</td><td>Pressure port (high pressure series) Fixing thread</td><td></td><td>SAE J518 2) DIN 13</td><td>400</td><td>0</td></tr><tr><td>B, 3)</td><td>Additional port</td><td></td><td>DIN 3852</td><td>400</td><td>X</td></tr><tr><td>B1 4)</td><td>2. Pressure port (high pressure series) fixing thread</td><td></td><td>SAE J518 2) DIN 13</td><td>400</td><td>(sX</td></tr><tr><td>S</td><td>Suction port Fixing thread</td><td></td><td>SAE J518 2) DIN 13</td><td>30</td><td>0</td></tr><tr><td>K1</td><td>Flow port</td><td></td><td>DIN 3852</td><td>4</td><td>X</td></tr><tr><td>K2</td><td>Flow port</td><td></td><td>DIN 3852</td><td>4</td><td>X</td></tr><tr><td>U</td><td>Flow port</td><td></td><td>DIN 3852</td><td>4</td><td>06)</td></tr><tr><td>T</td><td>Fluid drain</td><td></td><td>DIN 3852</td><td>4</td><td>X</td></tr><tr><td>R(L)</td><td>Fluid filling and air bleeding</td><td></td><td>DIN 3852</td><td>4</td><td>0</td></tr><tr><td>MB</td><td>Gauge port</td><td></td><td>DIN 3852</td><td>400</td><td>X</td></tr><tr><td>Ms</td><td>Gauge port</td><td></td><td>DIN 3852</td><td>30</td><td>X</td></tr><tr><td>M1, M2 7)</td><td>Gauge port for control pressure</td><td></td><td>DIN 3852</td><td>400</td><td>X</td></tr><tr><td>Mst</td><td>Gauge port for pilot pressure</td><td>DP</td><td>DIN 3853</td><td>400</td><td>X</td></tr><tr><td>Mst</td><td>Gauge port for pilot pressure</td><td>LR.H., LR.N.</td><td>DIN 3853</td><td>100</td><td>X</td></tr><tr><td>XD</td><td>Pilot pressure port for pressure control</td><td>DP,DRG, FRG(1)</td><td>DIN 3852</td><td>400</td><td>0</td></tr><tr><td>XF</td><td>Pilot pressure port for flow control</td><td>DPF, FR.(1), DFR(1)</td><td>DIN 3852</td><td>400</td><td>0</td></tr><tr><td>Rkv</td><td>External control fluid return (sizes 40-355)</td><td>LR..</td><td>DIN 3852</td><td>400</td><td>X</td></tr><tr><td>Rkv</td><td>Control fluid return</td><td>HS.</td><td>DIN 3852</td><td>5</td><td></td></tr><tr><td>Rkv</td><td>Control fluid return</td><td>EO1 (sizes 125,250),EO2</td><td>DIN 3852</td><td>5</td><td>X</td></tr><tr><td>Rkv</td><td>Pilot oil return (pipes)</td><td>DS1</td><td>DIN 3852</td><td>30</td><td>X</td></tr><tr><td>XLR</td><td>Pilot pressure port Remote adjustment for power control</td><td>LR3</td><td>DIN 3852</td><td>100</td><td>0</td></tr><tr><td>Pst Pst</td><td>Pilot pressure port Gauge port for pilot pressure</td><td>LR.H., LR.N. LR.NT</td><td>DIN 3852 DIN 3853</td><td>100 100</td><td>X X</td></tr></table></body></html>  

<html><body><table><tr><td>Designation</td><td>Function</td><td>Control device (optional)</td><td>Standard</td><td>Peak pressure (bar) 1)</td><td>State</td></tr><tr><td>X1, X2</td><td>Pilot pressure port</td><td>HD.P/T/U (sizes 40-71, sizes 500-1000)</td><td>DIN3853</td><td>100</td><td>(80</td></tr><tr><td>X1, X2</td><td>Pilot pressure port</td><td>HD.P/T/U (sizes 125-355)</td><td>DIN 3852</td><td>100</td><td>08)</td></tr><tr><td>X1, X2</td><td>Pilot pressure port</td><td>HD</td><td>DIN 3852</td><td>100</td><td>(80</td></tr><tr><td>X1, X2</td><td>Pilot pressure port</td><td>HM1</td><td>DIN 3852</td><td>100</td><td></td></tr><tr><td>X1, X2</td><td>Pilot pressure port</td><td>HM2, HS4M</td><td>DIN 3852</td><td>350</td><td></td></tr><tr><td>Sp</td><td>Control pressure port, accumulator port</td><td>EO1 (size 125,250)</td><td>DIN 3852</td><td>100</td><td>X</td></tr><tr><td>Sp</td><td>Control pressure port, accumulator port</td><td>EO2</td><td>DIN 3852</td><td>315</td><td>X</td></tr><tr><td>Sp</td><td>Control pressure port, accumulator port</td><td>HS., DS1</td><td>DIN 3852</td><td>350</td><td>X</td></tr><tr><td>P</td><td>Control pressure port</td><td>EO1</td><td>DIN 3852</td><td>100</td><td></td></tr><tr><td>P</td><td>Control pressure port</td><td>EO2</td><td>DIN 3852</td><td>315</td><td></td></tr><tr><td>P</td><td>Control pressure port</td><td>HS.</td><td>DIN 3852</td><td>350</td><td></td></tr><tr><td>P</td><td>Control pressure port</td><td>HD (sizes 40-355)</td><td>DIN 3853</td><td>400</td><td></td></tr><tr><td>P</td><td>Control pressure port</td><td>HD (sizes 500-1000), HD.P/T/U (sizes 125-355)</td><td>DIN3852</td><td>400</td><td></td></tr><tr><td>P</td><td>Pilot pressure port (pipes)</td><td>DS1</td><td>DIN 3852</td><td>350</td><td>X</td></tr><tr><td>R2-R7</td><td>Air bleeding of positioning chamber</td><td>EO2</td><td>DIN 3852</td><td>315</td><td>X</td></tr><tr><td>R2- R7</td><td>Air bleeding of positioning chamber</td><td>HM.(sizes 125-1000), HS. (sizes 125-1000)</td><td>DIN3852</td><td>350</td><td>X</td></tr></table></body></html>  

1) Brief pressure spikes may occur depending on the application. Keep this in mind when selecting measuring devices and armatures.  

2) Only dimensions according to SAE J518   
3) Version 13: available for sizes 40 to 355   
4) Version 25: available for sizes 40 to 1000   
5) Sealed with flange plate   
6) Must be connected for version for HFC hydraulic fluids   
7) Only present for series 3   
8) Condition and availability dependent on version and size  

$\bigcirc=$ Must be connected (plugged with plastic plugs on delivery) ${\mathsf X}=$ Plugged (in normal operation)  

Tightening torques  

The following tightening torques apply:  

•• Threaded hole in the axial piston unit: The maximum permissible tightening torques $\mathsf{M}_{\mathsf{G m a x}}$ are the maximum values of the threaded holes and must not be exceeded. For values, refer to the following table.   
•• Armatures: Observe the manufacturer's instruction regarding tightening torques for the used armatures.   
•• Fixing screws: For fixing screws according to DIN 13/ISO 68, we recommend checking the tightening torque in individual cases as per VDI 2230.   
•• Locking screws: For the metal locking screws supplied with the axial piston unit, the required tightening torques of locking screws MV apply. For values, refer to the following table.  

Table 9: Tightening torques of the threaded holes and locking screws   


<html><body><table><tr><td colspan="2">Threaded size of the ports</td><td>Max. permissible tightening torque of the threaded holes MGmax</td><td>Required tightening torque of the locking screws Mv</td><td>WAF hexagon socket</td></tr><tr><td>M10x1</td><td>DIN 3852</td><td>30 Nm</td><td>12 Nm</td><td>5mm</td></tr><tr><td>M12x1.5</td><td>DIN 3852</td><td>50 Nm</td><td>25 Nm</td><td>6 mm</td></tr><tr><td>M14x1.5</td><td>DIN 3852</td><td>80 Nm</td><td>35 Nm</td><td>6 mm</td></tr><tr><td>M16x1.5</td><td>DIN 3852</td><td>100 Nm</td><td>50 Nm</td><td>8 mm</td></tr><tr><td>M18x1.5</td><td>DIN 3852</td><td>140 Nm</td><td>60 Nm</td><td>8 mm</td></tr><tr><td>M22x1.5</td><td>DIN 3852</td><td>210 Nm</td><td>80 Nm</td><td>10 mm</td></tr><tr><td>M26x1.5</td><td>DIN 3852</td><td>230 Nm</td><td>120 Nm</td><td>12 mm</td></tr><tr><td>M27x2</td><td>DIN 3852</td><td>330 Nm</td><td>135 Nm</td><td>12 mm</td></tr><tr><td>M33x2</td><td>DIN 3852</td><td>540 Nm</td><td>225 Nm</td><td>17 mm</td></tr><tr><td>M42x2</td><td>DIN 3852</td><td>720 Nm</td><td>360 Nm</td><td>22 mm</td></tr><tr><td>M48x2</td><td>DIN 3852</td><td>900 Nm</td><td>400 Nm</td><td>24 mm</td></tr><tr><td>5/16-24UNF-2B</td><td>ISO 11926</td><td>10 Nm</td><td>7 Nm</td><td>1/8 in</td></tr><tr><td>3/8-24 UNF-2B</td><td>ISO 11926</td><td>20 Nm</td><td>7 Nm</td><td>5/32 in</td></tr><tr><td>7/16-20 UNF-2B</td><td>ISO 11926</td><td>40 Nm</td><td>15 Nm</td><td>3/16 in</td></tr><tr><td>9/16-18 UNF-2B</td><td>ISO 11926</td><td>80 Nm</td><td>25 Nm</td><td>1/4 in</td></tr><tr><td>3/4-16 UNF-2B</td><td>ISO 11926</td><td>160 Nm</td><td>62 Nm</td><td>5/16 in</td></tr><tr><td>7/8-14 UNF-2B</td><td>ISO 11926</td><td>240 Nm</td><td>127 Nm</td><td>3/8 in</td></tr><tr><td>1 1/16-12 UN-2B</td><td>ISO 11926</td><td>360 Nm</td><td>147 Nm</td><td>9/16 in</td></tr><tr><td>1 5/16-12 UN-2B</td><td>ISO 11926</td><td>540 Nm</td><td>198 Nm</td><td>5/8 in</td></tr><tr><td>1 5/8-12 UN-2B</td><td>ISO 11926</td><td>960 Nm</td><td>320 Nm</td><td>3/4 in</td></tr><tr><td>1 7/8-12 UN-2B</td><td>ISO 11926</td><td>1200 Nm</td><td>390 Nm</td><td>3/4 in</td></tr></table></body></html>  

<html><body><table><tr><td>Risk of mix-upswith threaded connections</td><td>The axial piston units are used in application areas with metric as well as with Imperialsystemsofunits. Both the system of units as well as the size of threaded hole and threaded plug (e.g. locking screw) must match.</td></tr><tr><td>WARNING!</td><td>Due to the lack of options for visually detecting differences, there is a risk of mix-ups.</td></tr><tr><td></td><td>Risk of damage to persons and property! If a threaded plug which is of a different measurement system and size with</td></tr><tr><td></td><td>respect to the threaded hole is pressurized, the threaded plug may loosen itself or even be ejected from the hole in a projectile-like manner. This can result in serious injury and damage to equipment. Hydraulic fluid can be</td></tr><tr><td></td><td>dischargedfromthisleakagepoint. Use the drawings (installation drawing/data sheet) to determine the required</td></tr><tr><td></td><td>threaded plug for each fitting.</td></tr><tr><td></td><td>screws and locking screws. For all threaded holes, use a threaded plug from the same system of units and</td></tr><tr><td></td><td>of the correctsize.</td></tr></table></body></html>  

Caution!  

#### 6.4.9	 Electrical connection of axial piston unit  

The machine or system manufacturer is responsible for the layout of the electric control.  

For electrically controlled axial piston units, the electric control must be connected according to the circuit diagram of the system manufacturer.  

#### Short circuit in event of penetrating hydraulic fluid!  

Fluid can penetrate the product and cause a short circuit.  

f Do not install electrically controlled axial piston units in a tank below the tank fluid level (tank installation).  

1.	 Switch off power supply to the relevant system component.  

2.	 Electrically connect the axial piston unit (12 or 24 V).  

<html><body><table><tr><td></td><td>7 Commissioning</td></tr><tr><td>WARNING!</td><td>Danger while working in the danger zone of a machine or system!</td></tr><tr><td></td><td>It is not permissible to work in the danger zone of a machine or system.</td></tr><tr><td></td><td>The machine or system must only be operated if safe working is ensured.</td></tr><tr><td></td><td>Pay attention to and rectify potential danger sources before commissioning the machine or system.</td></tr><tr><td></td><td>Nobody may stand in the danger zone of the machine or system.</td></tr><tr><td></td><td>operator'sreach.</td></tr><tr><td></td><td>Always follow the instructions of the machine or system manufacturer during commissioning.</td></tr><tr><td>CAUTION!</td><td></td></tr><tr><td></td><td>Risk of damage to persons and property!</td></tr><tr><td></td><td>Commissioning of the axial piston unit requires basic mechanical and hydraulic knowledge.</td></tr><tr><td></td><td>page 6) are authorized to commission the axial piston unit.</td></tr><tr><td>WARNING!</td><td></td></tr><tr><td></td><td>Riskoftoxication and injury!</td></tr><tr><td></td><td>damage, toxication upon inhalation).</td></tr><tr><td></td><td>Always check the lines for wear and damage before each commissioning.</td></tr><tr><td></td><td>While performing these checks, wear safety gloves, safety glasses and suitable working clothes.</td></tr><tr><td></td><td>If hydraulic fluid should, nevertheless, come into contact with your eyes or</td></tr><tr><td></td><td>penetrate your skin, consult a doctor immediately. When working with hydraulic fluids, strictly observe the safety instructions</td></tr><tr><td></td><td>provided by the hydraulic fluid manufacturer.</td></tr><tr><td></td><td></td></tr><tr><td>WARNING!</td><td></td></tr><tr><td></td><td>Fire hazard!</td></tr><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td></td><td>Hydraulic fluid is easily flammable.</td></tr><tr><td colspan="2"></td></tr></table></body></html>  

△  

ff Keep open flames and ignition sources from the axial piston unit.  

Caution!  

Missing seals and connections lead to noncompliance with the protection class! Fluids and contaminants may penetrate and damage the product. ff Prior to assembly, make sure that all seals and connectors are tight.  

#### 7.1 First commissioning  

<html><body><table><tr><td>CAUTION!</td><td>Risk of damage to the product! Anycontaminationof thehydraulicfluidleads towear and malfunctions. In particular, contaminants like e.g. welding beads or metal cuttings in the hydraulic linesmay damagethe axial pistonunit.</td></tr><tr><td>CAUTION!</td><td>Ensure utmost cleanliness during commissioning. Make sure that no contaminants penetrate when sealing the gauge ports. Risk of damage to the product! If you commission the axial piston unit without or with insufficient hydraulic fluid, the axial piston unit is damaged immediately or even destroyed.</td></tr><tr><td></td><td>When commissioning or recommissioning a machine or system, make sure are filled with hydraulic fluid and remain filled during operation. When commissioning the axial piston unit, observe the basic safety instructions and intendeduseprovided inchapter"2General safety</td></tr><tr><td></td><td>instructions".</td></tr><tr><td></td><td>7.1.1 Filling the axial piston unit You will require an approved hydraulic fluid:</td></tr><tr><td></td><td>The machine or system manufacturer can provide you with precise details on the hydraulic fluid. Details on minimum requirements for mineral-oil based hydraulic</td></tr><tr><td>CAUTION!</td><td>fluids, environmentally acceptable hydraulic fluids or HF hydraulic fluids for the axialpistonunitareavailableintheRexrothpublicationsRE90220,RE90221 and RE 90223,respectively. To ensure thefunctional reliability of the axial piston unit,cleanliness level</td></tr><tr><td></td><td>20/18/15 according to at least ISO 4406 is necessary for the hydraulic fluid. For permissibletemperatures,seethedatasheet. Risk of damage to the product!</td></tr><tr><td></td><td>An air pocket in the area near the bearings will damage the axial piston unit. Make certain that the pump case is completely filled with hydraulic fluid during</td></tr><tr><td></td><td>commissioning and during operation with the"drive shaft upwards"installation position.</td></tr><tr><td></td><td>Check the hydraulic fluid level in the case interior regularly; if necessary, thecasedrainlineafterlongerstandstill periods(airentersvia theshaftseal</td></tr><tr><td></td><td></td></tr><tr><td></td><td>lubricated when the pump is restarted. Make certain that the suction line is always filled with hydraulic fluid during commissioning and operation.</td></tr></table></body></html>  

The axial piston unit should be filled with a filling unit ( $10\mu\mathrm{m}$ filter grade).   
The axial piston unit must not be operated while it is being filled.  

Caution! △  

#### Danger of environmental contamination!  

The discharge or spillage of hydraulic fluid while filling the axial piston unit can lead to environmental pollution and contamination of the groundwater.  

f When filling and changing the hydraulic fluid, always place a catch pan under the axial piston unit.   
ff Observe the information in the safety data sheet for the hydraulic fluid and the specifications provided by the system manufacturer.   
1.	 Fill and air bleed the axial piston unit via the appropriate ports, see chapter "6.3 Installation position". The hydraulic lines of the system must also be filled.   
2.	 Test the direction of rotation of the engine. To do this, rotate the engine briefly at the lowest rotational speed (inching). Make sure that direction of rotation of the axial piston unit matches the details on the name plate, see also chapter "4.3 Product identification", Fig. 18: Name plate.   
3.	 Operate the axial piston pump at a lower speed (starter speed for internal combustion engines or inching operation for electric engines) until the pump system is completely filled and bled. To inspect, drain the hydraulic fluid at the case drain port and wait until it drains without bubbles.   
4.	 Make certain that all ports are either connected to pipes or plugged according to the general circuit diagram.  

#### 7.1.2	 Testing the hydraulic fluid supply  

The axial piston unit must always have a sufficient supply of hydraulic fluid. For this reason, the supply of hydraulic fluid must be ensured at the start of the commissioning process.  

When you test the hydraulic fluid supply, constantly monitor the noise development and check the hydraulic fluid level in the tank. If the axial piston unit becomes louder (cavitation) or the case drain fluid is discharged with bubbles, this is an indication that the axial piston unit is not being sufficiently supplied with hydraulic fluid.  

Notes on troubleshooting can be found in chapter "14 Troubleshooting".  

To test the hydraulic fluid supply:  

1.	 Allow the engine to run at the slowest speed. The axial piston unit must be operated without load. Pay attention to leakage and noise.   
2.	 Check the axial piston unit’s case drain line during the test. The case drain fluid should not contain any bubbles.   
3.	 Check the suction pressure at port "S" of the axial piston pump. Refer to data sheet RE 92050 for the permissible value.   
4.	 Check the case drain pressure at connected port $"{\bf K}_{1}"$ or $"{\bf K}_{2}"$ . Refer to data sheet RE 92050 for the permissible value.  

#### 7.1.3	 Performing functional test  

Warning!  

#### Risk of injury in case of incorrectly connected machine or system!  

Any change of the connections will lead to malfunctions (e.g. lift instead of lower) and thus represents a corresponding danger to persons and equipment.  

$\blacktriangleright$ f When connecting hydraulic components, observe the specified piping according to the hydraulic circuit diagram of the machine or system manufacturer.  

Once you have tested the hydraulic fluid supply, you must perform a functional test on the machine or system. The functional test should be performed according to the instructions of the machine or system manufacturer.  

The axial piston unit is checked for functional capability before delivery according to the technical data. During commissioning, it must be ensured that the axial piston unit was installed in accordance with the design of the machine or system. Use the swivel angle indicator to check whether the axial piston unit swivels in and out correctly during operation.  

The position of the swivel angle indicator and the assignment of the swivel direction to the direction of rotation and control can be found in the corresponding technical data sheets.  

#### 7.1.4	 Performing flushing cycle  

In order to remove foreign bodies from the system, Rexroth recommends a flushing cycle for the entire system.  

During the flushing cycle, the axial piston unit must be operated without load. The flushing cycle can be performed, e.g. by using an additional flushing unit. Follow the instructions of the flushing unit's manufacturer for the exact procedure during the flushing cycle.  

#### 7.2	 Recommissioning after downtime  

Depending on the installation conditions and ambient conditions, changes may occur in the system which make recommissioning necessary.  

Among others, the following criteria may make recommissioning necessary:  

•• Air in the hydraulic system •• Water in the hydraulic system •• Old hydraulic fluid •• Other contamination  

$\blacktriangleright$ Before recommissioning, proceed as described in chapter "7.1 First commissioning".  

#  

<html><body><table><tr><td>.3</td><td>Ruhhihg-inphase The bearings and sliding surfaces are subject to a running-in phase. The increased friction at the start of the running-in phase results in increased heat developmentwhichdecreaseswithincreasing operatinghours.Thevolumetric and mechanical-hydraulic efficiency increases as well through the conclusion of</td></tr><tr><td>CAUTION!</td><td>therunning-inphaseofapprox.10operatinghours. Riskofdamagebyinsufficientviscosity!</td></tr><tr><td></td><td>The increased temperature of thehydraulic fluid during the running-inphase can</td></tr><tr><td></td><td>causetheviscositytodroptoimpermissiblelevels.</td></tr><tr><td></td><td>Reduce the loading (pressure, rpm) of the axial piston unit if impermissible</td></tr></table></body></html>  

#### 8 Operation  

The product is a component which requires no settings or changes during operation. For this reason, this chapter of the manual does not contain any information on adjustment options. Only use the product within the performance range provided in the technical data. The machine or system manufacturer is responsible for the proper project planning of the hydraulic system and its control.  

#### 9 Maintenance and repair  

#### 9.1 Cleaning and care  

Caution!  

#### Damage to the surface caused by solvents and aggressive detergents!  

Aggressive detergents may damage the seals on the axial piston unit and cause them to age faster.  

ff Never use solvents or aggressive detergents.  

Caution!  

#### Damage to the hydraulic system and the seals!  

A high-pressure cleaner's water pressure could damage the electronics and the seals of the axial piston unit.  

f Do not point the high-pressure cleaner at sensitive components such as, e.g. shaft seal ring, electrical connections and electrical components.  

For cleaning and care of the axial piston unit, observe the following:  

ff Plug all openings with suitable protective caps/devices.   
ff Check whether all seals and plugs of the plug connections are securely seated to ensure that no moisture can penetrate into the axial piston unit during cleaning.   
ff Use only water and, if necessary, a mild detergent to clean the axial piston unit.   
ff Remove coarse dirt from the outside of the machine and keep sensitive and important components, such as solenoids, valves and displays, clean.  

#### 9.2 Inspection  

In order to enable long and reliable operation of the axial piston unit, Rexroth recommends testing the hydraulic system and axial piston unit on a regular basis and to document the following operating conditions:  

Table 10: Inspection schedule   


<html><body><table><tr><td colspan="2">Tasktobecarriedout</td><td>Interval</td></tr><tr><td rowspan="3">Hydraulic system</td><td>Check level of hydraulic fluid in the tank.</td><td>daily</td></tr><tr><td>Checkoperatingtemperature (comparable load state).</td><td>weekly</td></tr><tr><td>Check quality of the hydraulic fluid.</td><td>yearlyorevery 2000h(which ever occurs first)</td></tr><tr><td rowspan="3">Axial piston unit</td><td>Check axial piston unit forleakage. Earlydetectionofhydraulicfluidlosscanhelp identify and rectify faults on the machine or system.Forthis reason,Rexroth recommends that the axial pistonunit and system always be kept in a clean condition.</td><td>daily</td></tr><tr><td>Checkaxialpistonunitfornoisedevelopment.</td><td>daily</td></tr><tr><td>Checkfixingelementsfortightseating. Allfixingelementshavetobecheckedwhen thesystemis switched off,depressurized and cooled down.</td><td>monthly</td></tr></table></body></html>  

#### 9.3 Maintenance  

The axial piston unit is low maintenance when used as intended.  

The service life of the axial piston unit is heavily dependent on the quality of the hydraulic fluid. For this reason, we recommend changing the hydraulic fluid at least once per year or every 2000 operating hours (which ever occurs first) or having it analyzed by the hydraulic fluid manufacturer or a laboratory to determine its suitability for further use.  

The service life of the axial piston unit is limited by the service life of the built-in bearings. The service life can be requested on the basis of the load cycle from the responsible Rexroth Service partner, see $"9.5$ Spare parts" for address. Based on these details, a maintenance period is to be determined by the system manufacturer for the replacement of the bearings and included in the maintenance schedule of the hydraulic system.  

#### 9.4 Repair  

Rexroth offers a comprehensive range of services for the repair of Rexroth axial piston units.  

Repairs of the axial piston unit may only be performed by authorized, skilled and instructed staff.  

Only use genuine spare parts from Rexroth for repairing the Rexroth axial piston units.  

Tested and pre-assembled original Rexroth assembly groups allow for successful repair requiring only little time.  

#### 9.5 Spare parts  

CAUTION!  

#### Damage to persons and property due to faulty spare parts!  

Spare parts that do not meet the technical requirements specified by Rexroth may cause damage to persons or property.  

f Use only original spare parts from Rexroth.  

The list of spare parts for axial piston units are order specific. When ordering spare parts, please quote the material and serial number of the axial piston unit as well as the material numbers of the spare parts.  

Please address all questions regarding spare parts to your responsible Rexroth Service partner or the service department of the manufacture's plant for the axial piston unit.  

Bosch Rexroth AG An den Kelterwiesen 14 72160 Horb am Neckar, Germany Phone $+49$ (0)74 51 - 92 0 Fax $^{+49}$ (0)74 51 - 82 21 service.horb@boschrexroth.de  

For the addresses of foreign subsidiaries, please refer to www.boschrexroth.com/addresses  

#### 10	Decommissioning  

The axial piston unit is a component that does not require decommissioning. For this reason, this chapter of the manual does not contain any information For details about how to disassemble or replace your axial piston unit, please refer to chapter "11 Disassembly and replacement".  

#### 11	Disassembly and replacement  

#### 11.1	 Required tools  

Disassembly can be performed with standard tools. No special tools are necessary.  

#### 11.2	 Preparing disassembly  

WARNING!  

#### Risk of injuries due to disassembling under pressure and voltage!  

If you do not switch off the pressure and power supply before disassembling the product, you may get injured or the device or system components may be damaged.  

Make sure that the relevant system components are not under pressure or voltage.   
1.	 Decommission the entire system as described in the overall manual for the machine or system.   
2.	 Relieve the hydraulic system according to the instructions of the machine or system manufacturer.  

#### 11.3	 Disassembling the axial piston unit  

Proceed as follows to disassemble the axial piston unit:  

1.	 Make sure that the hydraulic system is depressurized.   
2.	 Check whether the axial piston unit has cooled down far enough so that it can be disassembled without danger.   
3.	 Place a catch pan under the axial piston unit to collect any hydraulic fluid that may escape.  

https://d3d2iaoi1ibop8.cloudfront.net/Output/A4VSO_INSTRUCTION/images/7e64e89bb727140e93c53998513ecf033f77aa7a538e8e22cb1c8509325c83f9.jpg  

#### Danger of environmental contamination!  

The discharge or spillage of hydraulic fluid while filling the axial piston unit can lead to environmental pollution and contamination of the groundwater.  

ff When filling and changing the hydraulic fluid, always place a catch pan under the axial piston unit. Observe the information in the safety data sheet for the hydraulic fluid and the specifications provided by the system manufacturer.  

4.	 Loosen the lines and collect the escaping hydraulic fluid in the collector.  

5.	 Remove the axial piston unit. Use an appropriate lifting device.   
6.	 Completely empty the axial piston unit.   
7.	 Plug all openings.  

#### 11.4	 Preparing the components for storage or further use  

ff Proceed as described in section "5.2 Storing the axial piston unit".  

#### 12	Disposal  

Observe the following points when disposing of the axial piston unit:  

1.	 Completely empty the axial piston unit.   
2.	 Dispose of the hydraulic fluid according to the national regulations of your country.   
3.	 Disassemble the axial piston unit into its individual parts and properly recycle these parts.  

4.	 Separate parts by:  

–– Cast parts   
–– Steel   
–– Nonferrous metal –– Electronic waste –– Plastic   
–– Seals.  

#### 12.1	 Environmental protection  

Careless disposal of the axial piston unit, the hydraulic fluid and the packaging material could lead to pollution of the environment.  

f Therefore, dispose of the axial piston unit, the hydraulic fluid and the   
packaging material in accordance with the currently applicable regulations in   
your country. Dispose of hydraulic fluid residues according to the applicable safety data   
sheets for these hydraulic fluids.  

#### 13	Extension and conversion  

Do not convert the axial piston unit. This also includes a modification of the adjusting screws.  

The warranty from Rexroth only applies to the delivered configuration. In case of extensions or conversions, the warranty will become void.  

The adjusting screws are protected against unauthorized resetting by means of protective caps. Removal of the protective caps will void the warranty. If you need to modify the setting, please contact your responsible Rexroth Service (address as to chapter "9.5 Spare parts").  

#### 14	Troubleshooting  

The following table may assist you in troubleshooting. The table makes no claim for completeness.  

In practical use, problems which are not listed here may also occur.  

#### 14.1	 How to proceed for troubleshooting  

f Always act systematically and targeted, even under pressure of time. Random and imprudent disassembly and readjustment of settings might result in the inability to ascertain the original error cause.   
f First obtain a general overview of how your product works in conjunction with the entire system.   
$\blacktriangleright$ Try to determine whether the product worked properly in conjunction with the entire system before the troubles occurred.   
$\blacktriangleright$ Try to determine any changes of the entire system in which the product is integrated. –– Were there any changes to the product's operating conditions or operating range? –– Were there any changes or repairs on the complete system (machine / system, electrics, control) or on the product? If yes, which? –– Was the product or machine used as intended? –– How did the malfunction appear?  

$\blacktriangleright$ Try to get a clear idea of the error cause. Directly ask the (machine) operator. $\blacktriangleright$ If you cannot rectify the error, contact one of the contact addresses which can be found under: www.boschrexroth.com/addresses.  

#### Troubleshooting  

#### 14.2	 Malfunction table  

Table 11: Malfunction table for variable pumps   


<html><body><table><tr><td>Fault</td><td>Possible cause</td><td>Remedy</td></tr><tr><td>Unusual noises</td><td>Drive speed too high.</td><td>Machine or systemmanufacturer.</td></tr><tr><td rowspan="8"></td><td>Wrong direction of rotation.</td><td>Ensurecorrectdirectionofrotation.</td></tr><tr><td rowspan="2">Insufficient suction conditions,e.g.airin the suctionline,insufficientdiameterofthesuction line, viscosity of the hydraulic fluid too high,</td><td>Machine or system manufacturer (e.g. optimize</td></tr><tr><td>inlet conditions, use suitable hydraulic fluid). Completely air bleed axial piston unit, fill suction</td></tr><tr><td rowspan="2">low, contaminants in the suction line. Improper fixing of the axial piston unit</td><td>linewithhydraulic fluid. Removecontaminantsfromthesuctionline.</td></tr><tr><td>Check fixing of the axial piston unit according to the specifications of the machine or system</td></tr><tr><td>Improper fixing of the attachment parts, e.g. coupling and hydraulic lines.</td><td>manufacturer. Observe tightening torques. Fixattachmentpartsaccordingtothe information provided by the coupling or armature manufacturer.</td></tr><tr><td>Pressure-reliefvalves of the axialpistonunit.</td><td>Air bleed axial piston unit Check viscosity of the hydraulic fluid Contact RexrothService.</td></tr><tr><td>Mechanical damage to theaxialpistonunit.</td><td>Exchange axial piston unit, contact Rexroth Service.</td></tr><tr><td rowspan="6">No or insufficient flow</td><td>Faulty mechanical drive(e.g.defective coupling).</td><td>Machine or system manufacturer.</td></tr><tr><td>Drive speed too low. Insufficient suction conditions, e.g. air in the</td><td>Machine or systemmanufacturer.</td></tr><tr><td rowspan="3">suctionline,insufficientdiameterofthesuction line,viscosity of the hydraulic fluid too high, suctionheighttoohigh,suctionpressuretoo low,contaminantsin the suctionline.</td><td>Machine or system manufacturer (e.g. optimize inletconditions,usesuitablehydraulicfluid).</td></tr><tr><td>Completely air bleed axial piston unit, fill suction line with hydraulic fluid.</td></tr><tr><td>Removecontaminantsfromthesuctionline.</td></tr><tr><td>Hydraulicfluid not in optimum viscosity range.</td><td>Use suitable hydraulic fluid (machine or system manufacturer).</td></tr><tr><td rowspan="7"></td><td>Externalcontrolofthecontroldevicedefective.</td><td>Check external control(machine orsystem manufacturer).</td></tr><tr><td>Insufficient pilot pressure.</td><td>Checkpilotpressure,contactRexrothService.</td></tr><tr><td>Malfunction of the control device or controller of the axial pistonunit.</td><td>ContactRexrothService.</td></tr><tr><td>Wear of axial piston unit.</td><td>Exchange axial piston unit, contact Rexroth Service.</td></tr><tr><td>Mechanical damage to theaxialpistonunit.</td><td>Exchange axial piston unit, contact Rexroth</td></tr><tr><td></td><td>Service.</td></tr></table></body></html>  

Table 11: Malfunction table for variable pumps   


<html><body><table><tr><td>Fault</td><td>Possible cause</td><td>Remedy</td></tr><tr><td>No or insufficient pressure</td><td>Faulty mechanical drive (e.g. defective coupling).</td><td>Machine or system manufacturer.</td></tr><tr><td rowspan="9"></td><td>Drive power too low.</td><td>Machine or system manufacturer.</td></tr><tr><td rowspan="3">Insufficient suction conditions, e.g. air in the suction line, insufficient diameter of the suction line, viscosity of the hydraulic fluid too high, suction height too high, suction pressure too</td><td>Machine or system manufacturer (e.g. optimize inlet conditions, use suitable hydraulic fluid).</td></tr><tr><td>Completely air bleed axial piston unit, fill suction</td></tr><tr><td>line with hydraulic fluid. Remove contaminants from the suction line.</td></tr><tr><td>Hydraulic fluid not in optimum viscosity range.</td><td>Use suitable hydraulic fluid (machine or system manufacturer).</td></tr><tr><td>Externalcontrolofthecontroldevicedefective.</td><td>Check external control(machine orsystem manufacturer).</td></tr><tr><td>Insufficient pilot pressure.</td><td>Check pilot pressure, contact Rexroth Service.</td></tr><tr><td>Malfunction of the control device or controller of theaxial pistonunit.</td><td>ContactRexrothService.</td></tr><tr><td>Wear of axial piston unit.</td><td>Exchange axial piston unit, contact Rexroth Service.</td></tr><tr><td>Mechanical damage to the axial piston unit.</td><td>Exchange axial piston unit, contact Rexroth Service.</td></tr><tr><td rowspan="3">Pressure/flowfluctuations</td><td>Output unit defective (e.g. hydraulic motor or cylinder).</td><td>Machine or system manufacturer.</td></tr><tr><td>Axial piston unit not or insufficiently air bled. Insufficient suction conditions, e.g. air in the suctionline,insufficientdiameterofthesuction</td><td>Completely air bleed axial piston unit. Machine or system manufacturer (e.g. optimize</td></tr><tr><td rowspan="3">line, viscosity of the hydraulic fluid too high, suction height too high, suction pressure too</td><td>inlet conditions,use suitablehydraulic fluid). Completely air bleed axial piston unit, fill suction</td></tr><tr><td rowspan="2">low,contaminantsin the suctionline. Excessive inlet temperature at the axial piston</td><td>line with hydraulic fluid. Removecontaminantsfromthesuctionline.</td></tr><tr><td>Machine or systemmanufacturer:</td></tr><tr><td rowspan="3"></td><td>unit. Malfunctionof thepressurecontrol valves</td><td>inspect system, e.g. malfunction of the cooler, insufficient hydraulicfluid in the tank. Contact Rexroth Service.</td></tr><tr><td>(e.g.high-pressure relief valve,pressure cut-off, pressure control). Wear of axial piston unit.</td><td></td></tr><tr><td></td><td>Exchange axial piston unit, contact Rexroth Service.</td></tr></table></body></html>  

#### 15	Technical data  

The technical data of your axial piston unit can be found in data sheet "RE 92050" or "RE 92053" (for HFC hydraulic fluids). Depending on your axial piston pump's control unit, other technical data sheets apply: RE 92056, RE 92060, RE 92064, RE 92072, RE 92076, RE 92080 and RE 92088.  

The data sheet can be found on the Internet under   
www.boschrexroth.com/ics   
The preset technical data of your axial piston unit can be found in the order confirmation.  

#### 16	Appendix  

#### 16.1	 Address directory  

For the addresses of foreign subsidiaries, please refer to www.boschrexroth.com/addresses  

#### 17	Index  

#### A  

Abbreviations  5   
Above-tank installation  30   
Address directory  56   
Assembly  11, 26 Completing  35 General instructions  32 Preparation  31   
Axial piston unit Assembling  31 Assembly  11 Conversion  52 Dimensions  32 Disassembling  50 Filling  43 Installation conditions  26 Installation position  28 Maintaining  49 Maintenance  48 Repair  49 Replacing  50 Storing  24 transporting  23 Unpacking  26 Weight  23  

#### B  

Below-tank installation  28  

#### C  

Care  48   
Caution  7   
Circuit diagram  13   
Cleaning  48   
Commissioning  42 first  43   
Connecting Electrical  41 Hydraulic  36   
Control Electric motorized  18 Hydraulic  17, 18, 19 Manual  17   
Control device  13   
Control plate  11   
Control system  19, 20 Electro-hydraulic  21   
Control unit  11   
Conversion  52   
Corrosion protection  24   
Cylinder  11  

#### D  

Danger  7   
Data sheet  4   
Decommissioning  50   
Delivery contents  10   
Device description  11  

Dimensions  23, 32   
Direction of rotation  31   
Disassembly  50 Performing  50 Preparing  50   
Disposal  52   
Documentation  4   
Drive shaft  11  

#### E  

Environmental protection  52  

#### F  

Filling  43   
Flow control  14   
Flushing cycle  45   
Functional description  12 Control  12 Pump  12   
Functional test  45  

#### G  

General instructions  32  

#### H  

High-pressure side  11   
Hydraulic fluid  43  

#### I  

Identification  22   
Improper use  6   
Inspection  48   
Inspection schedule  48   
Installation On a gearbox  34 With cardan shaft  34 With coupling  33   
Installation conditions  26   
Installation drawing  4   
Installation position  28   
Interval  48  

#### L  

Lifting device  23   
Low-pressure side  11  

#### M  

Maintenance  48, 49   
Malfunction table  54  

#### N  

Name plate  22   
Notes  7  

#### O  

Operation  47   
Operator's   
obligations  9   
Order confirmation  4   
Ordering code  22  

#### P  

Performance description  11   
Piston  11   
Port overview  38   
Port plate  11   
Power control  15, 16   
Hyperbolic  15, 16   
Pressure and flow control  14   
Pressure controller  13   
Parallel operation  13   
Product description  11  

Q Qualifications Personnel  6  

#### R  

Recommissioning   
after downtime  45   
Repair  48, 49   
Retaining plate  11   
Ring screw  23   
Running-in phase  46  

#### S  

Safety instructions  6, 7   
Slipper pad  11   
Spare parts  49   
Speed control  20   
Storage  23   
Storage time  25   
Stroke piston  11   
Suction port  11   
Swashplate  11   
Swivel angle  12   
Swivel angle indicator  32  

#### T  

Tank installation  29   
Technical data  56   
Tightening torques  40   
Tools  50   
Transport  23 With lifting strap  24 With ring screw  23   
Troubleshooting  53  

#### W  

Warning  7   
Warranty  7, 25, 35, 43   
Weights  23  

Bosch Rexroth AG   
Hydraulics   
Axial Piston Units   
An den Kelterwiesen 14   
72160 Horb, Germany   
Phone $+49$ (0) 74 51 92-0   
Fax $+49$ (0) 74 51 82 21   
info.brm-ak@boschrexroth.de   
www.boschrexroth.com/brm  